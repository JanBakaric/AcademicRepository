package baza;

import dodatno.OvlastGosta;
import entiteti.Gost;
import entiteti.Knjiga;
import iznimke.DBPropertyException;
import iznimke.QueryException;
import iznimke.SpajanjeNaBazuException;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static glavna.AkademskiRepozitorij.logger;

public class BazaPodataka<T> {
    private ArrayList<T> podaci = new ArrayList<>();

    public static Connection connectToDatabase() throws SpajanjeNaBazuException, DBPropertyException {
        Properties konfiguracijaBaze = new Properties();
        String dbURL;
        String username;
        String password;

        try (FileInputStream fis = new FileInputStream("src/main/resources/dat/bazaPodataka.properties")) {
            konfiguracijaBaze.load(fis);
            dbURL = konfiguracijaBaze.getProperty("bazaPodatakaURL");
            username = konfiguracijaBaze.getProperty("korisnickoIme");
            password = konfiguracijaBaze.getProperty("lozinka");
        } catch (IOException ioException) {
            throw new DBPropertyException(ioException.getMessage(), ioException.getCause());
        }

        try {
            return DriverManager.getConnection(dbURL, username, password);
        } catch (SQLException sqlException) {
            throw new SpajanjeNaBazuException(sqlException.getMessage(), sqlException.getCause());
        }
    }

    public static <T> ArrayList<T> dohvatiPodatke(String nazivBaze) throws SpajanjeNaBazuException, DBPropertyException {
        ArrayList<T> dohvat = new ArrayList<>();

        try (Connection veza = connectToDatabase(); Statement stmt = veza.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM " + nazivBaze.toUpperCase())) {

            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                List<Object> rowData = new ArrayList<>();
                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                    rowData.add(rs.getObject(i));
                }
                dohvat.add((T) rowData);
            }

            return dohvat;
        } catch (SQLException sqlException) {
            throw new SpajanjeNaBazuException(sqlException.getMessage(), sqlException.getCause());
        }
    }

    public static ArrayList<Gost> dohvatiKorisnike() throws SpajanjeNaBazuException, DBPropertyException {
        ArrayList<Gost> korisnici = new ArrayList<>();
        ArrayList<ArrayList> liste = new ArrayList<>(dohvatiPodatke("KORISNICI_ZA_OVJERU"));

        for (ArrayList arrayList : liste) {
            Integer id = Integer.parseInt(arrayList.get(0).toString());
            String jmbag = arrayList.get(1).toString();
            String ime = arrayList.get(2).toString();
            String prezime = arrayList.get(3).toString();
            String email = arrayList.get(4).toString();
            String lozinka = arrayList.get(5).toString();
            LocalDate datumRodjenja = LocalDate.parse(arrayList.get(6).toString());
            String kIme = (arrayList.get(2).toString().substring(0, 1) + arrayList.get(3)).toLowerCase();
            Gost korisnik = new Gost(id, ime, prezime, kIme, lozinka, datumRodjenja, email, OvlastGosta.AKADEMIK, jmbag);
            korisnici.add(korisnik);
        }
        return korisnici;
    }

    public static void unesiKorisnikaOvjeriti(String jmbag, String ime, String prezime, String email, String lozinka, LocalDate datumRodjenja) throws QueryException, DBPropertyException {
        try (Connection con = connectToDatabase(); PreparedStatement stmt = con.prepareStatement("INSERT INTO KORISNICI_ZA_OVJERU (jmbag, ime, prezime, email, lozinka, datum_rodjenja) VALUES (?, ?, ?, ?, ?, ?)")) {

            stmt.setString(1, jmbag);
            stmt.setString(2, ime);
            stmt.setString(3, prezime);
            stmt.setString(4, email);
            stmt.setString(5, lozinka);
            stmt.setDate(6, Date.valueOf(datumRodjenja));
            stmt.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Spremanje korisnika");
            alert.setHeaderText("Uspješno ste se registrirali");
            alert.setContentText("Registriran korisnik " + ime + " " + prezime + ". Molimo Vas da pričekate naše djelatnike da odobre Vaš račun!");
            alert.show();
        } catch (SQLException sqlException) {
            throw new QueryException(sqlException.getMessage(), sqlException.getCause());
        }
    }

    public static ArrayList<Knjiga> dohvatiKnjige() throws SpajanjeNaBazuException, DBPropertyException {
        ArrayList<Knjiga> knjige = new ArrayList<>();
        ArrayList<ArrayList> liste = new ArrayList<>(dohvatiPodatke("KNJIGA"));

        try {
            for (ArrayList arrayList : liste) {
                Integer id = (Integer) arrayList.get(0);
                String naziv = arrayList.get(1).toString();
                String imeAutora = arrayList.get(2).toString();
                String prezimeAutora = arrayList.get(3).toString();
                String godinaIzdanja = arrayList.get(4) != null ? arrayList.get(4).toString() : "Neodređena godina izdanja";
                String zemljaPorijekla = arrayList.get(5) != null ? arrayList.get(5).toString() : "Neodređena zemlja porijekla";
                String izdavac = arrayList.get(6) != null ? arrayList.get(6).toString() : "Neodređen izdavać";
                String putanja = arrayList.get(7) != null ? arrayList.get(7).toString() : "Neodređena putanja";
                Integer tipKnjige = arrayList.get(8) != null ? (Integer) arrayList.get(8) : 0;
                String objavitelj = arrayList.get(9) != null ? arrayList.get(9).toString() : "Neodređen objavitelj";
                Knjiga.KnjigaBuilder knjigaB = new Knjiga.KnjigaBuilder(id, naziv, imeAutora, prezimeAutora);

                knjigaB.setGodinaIzdanja(godinaIzdanja);
                knjigaB.setZemljaPorijekla(zemljaPorijekla);
                knjigaB.setIzdavac(izdavac);
                knjigaB.setPutanja(putanja);
                knjigaB.setTipKnjige(tipKnjige);
                knjigaB.setObjavitelj(objavitelj);
                knjige.add(knjigaB.build());
            }
        } catch (NullPointerException nullPointerException) {
            System.err.println("Jedna ili više vrijednosti je null!");
        }
        return knjige;
    }

    public static ArrayList<Knjiga> dohvatiKnjigeZaOvjeru() throws SpajanjeNaBazuException, DBPropertyException {
        ArrayList<Knjiga> knjige = new ArrayList<>();
        ArrayList<ArrayList> liste = new ArrayList<>(dohvatiPodatke("KNJIGE_ZA_OVJERU"));

        for (ArrayList arrayList : liste) {
            Integer id = (Integer) arrayList.get(0);
            String naziv = arrayList.get(1).toString();
            String imeAutora = arrayList.get(2).toString();
            String prezimeAutora = arrayList.get(3).toString();
            String godinaIzdanja = arrayList.get(4) != null ? arrayList.get(4).toString() : "Neodređena godina izdanja";
            String zemljaPorijekla = arrayList.get(5) != null ? arrayList.get(5).toString() : "Neodređena zemlja porijekla";
            String izdavac = arrayList.get(6) != null ? arrayList.get(6).toString() : "Neodređen izdavać";
            String putanja = arrayList.get(7) != null ? arrayList.get(7).toString() : "Neodređena putanja";
            String objavitelj = arrayList.get(8) != null ? arrayList.get(8).toString() : "Neodređen objavitelj";
            Knjiga.KnjigaBuilder knjigaB = new Knjiga.KnjigaBuilder(id, naziv, imeAutora, prezimeAutora);

            knjigaB.setGodinaIzdanja(godinaIzdanja);
            knjigaB.setZemljaPorijekla(zemljaPorijekla);
            knjigaB.setIzdavac(izdavac);
            knjigaB.setPutanja(putanja);
            knjigaB.setObjavitelj(objavitelj);
            knjige.add(knjigaB.build());
        }
        return knjige;
    }

    public static void ovjerenjeKnjige(Knjiga knjiga) {
        ButtonType yesButton = new ButtonType("Da");
        ButtonType noButton = new ButtonType("Ne");

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Spremanje knjige");
        alert.setHeaderText("Jeste li sigurni?");
        alert.setContentText("Želite li dodati knjigu " + knjiga.getNaziv() + "?");
        alert.getButtonTypes().setAll(yesButton, noButton);
        alert.showAndWait().ifPresent(buttonType -> {
            if (buttonType == yesButton) {
                try (Connection con = connectToDatabase(); PreparedStatement stmt = con.prepareStatement("INSERT INTO KNJIGE_ZA_OVJERU (naslov, ime_autora, prezime_autora, godina_izdanja, zemlja_porijekla, izdavac, putanja, objavitelj) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
                    String novaPutanja = "";
                    if (knjiga.getPutanja().endsWith(".txt"))
                        novaPutanja = "datoteke/privremene/" + knjiga.getNaziv() + ".txt";
                    if (knjiga.getPutanja().endsWith(".pdf"))
                        novaPutanja = "datoteke/privremene/" + knjiga.getNaziv() + ".pdf";
                    if (knjiga.getPutanja().endsWith(".docx"))
                        novaPutanja = "datoteke/privremene/" + knjiga.getNaziv() + ".docx";

                    stmt.setString(1, knjiga.getNaziv());
                    stmt.setString(2, knjiga.getImeAutora());
                    stmt.setString(3, knjiga.getPrezimeAutora());
                    stmt.setString(4, knjiga.getGodinaIzdanja());
                    stmt.setString(5, knjiga.getZemljaPorijekla());
                    stmt.setString(6, knjiga.getIzdavac());
                    stmt.setString(7, novaPutanja);
                    stmt.setString(8, knjiga.getObjavitelj());
                    stmt.executeUpdate();

                    Files.copy(Path.of(knjiga.getPutanja()), Path.of(novaPutanja), StandardCopyOption.REPLACE_EXISTING);
                } catch (SQLException sqlException) {
                    logger.error(sqlException.getMessage(), sqlException.getCause());
                } catch (IOException ioException) {
                    logger.error("Greška tijekom obrade datoteke", ioException.getCause());
                }
            }
        });
    }

    public ArrayList<T> getPodaci() {
        return podaci;
    }

    public void setPodaci(ArrayList<T> podaci) {
        this.podaci = podaci;
    }
}