package glavna;

import dodatno.FXMLLoaderSpajanje;
import iznimke.FXMLLoaderException;
import javafx.application.Application;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AkademskiRepozitorij extends Application {
    public static final Logger logger = LoggerFactory.getLogger(AkademskiRepozitorij.class);
    private static Stage mainStage;

    public static void main(String[] args) {
        launch();
    }

    public static Stage getMainStage() {
        return mainStage;
    }

    @Override
    public void start(Stage stage) throws FXMLLoaderException {
        mainStage = stage;

        FXMLLoaderSpajanje.spoji("prijava.fxml", "Korisnička Prijava", stage);
        stage.setAlwaysOnTop(false);
    }
}