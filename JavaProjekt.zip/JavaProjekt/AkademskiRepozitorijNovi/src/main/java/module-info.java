module akademskirepozitorijnovi {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jdk.httpserver;
    requires java.desktop;
    requires org.slf4j;

    opens glavna to javafx.fxml;
    exports glavna;
    exports kontroleri;
    opens kontroleri to javafx.fxml;
}