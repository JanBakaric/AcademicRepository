package iznimke;

import javafx.scene.control.Alert;

import java.sql.SQLException;

import static glavna.AkademskiRepozitorij.logger;

public class SpajanjeNaBazuException extends SQLException {
    public SpajanjeNaBazuException(String reason, Throwable cause) {
        logger.error(reason, cause);
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Pogreška pri spajanju na bazu podataka");
        alert.setHeaderText(null);
        alert.setContentText("Molimo Vas da provjerite svoju vezu s bazom");
        alert.show();
    }
}
