package iznimke;

import javafx.scene.control.Alert;

import java.sql.SQLException;

import static glavna.AkademskiRepozitorij.logger;

public class QueryException extends SQLException {
    public QueryException(String reason, Throwable cause) {
        logger.error(reason, cause);
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Pogreška pri spajanju na bazu podataka");
        alert.setHeaderText(null);
        alert.setContentText("Molimo Vas da provjerite svoj upit!");
        alert.show();
    }

}
