package iznimke;

import java.time.LocalDateTime;

import static glavna.AkademskiRepozitorij.logger;

public class NeuspjelaPrijavaException extends Exception {
    public NeuspjelaPrijavaException() {
        logger.info("Neuspjela prijava " + LocalDateTime.now());
    }
}
