package iznimke;

import javafx.scene.control.Alert;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public class DBPropertyException extends IOException {
    public DBPropertyException(String message, Throwable cause) {
        logger.warn(message, cause);
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Pogreška pri spajanju na .properties datoteku");
        alert.setHeaderText(null);
        alert.setContentText("Molimo Vas da provjerite svoju vezu s datotekom!");
        alert.show();
    }
}
