package iznimke;

import javafx.scene.control.Alert;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public class PreuzimanjeException extends IOException {
    public PreuzimanjeException(String message, Throwable cause) {
        logger.error(message, cause);
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Pogreška pri spajanju na bazu podataka");
        alert.setHeaderText(null);
        alert.setContentText("Molimo Vas da provjerite svoju vezu s bazom");
        alert.show();
    }
}
