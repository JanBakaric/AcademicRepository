package sucelja;

import dodatno.FXMLLoaderSpajanje;
import glavna.AkademskiRepozitorij;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import kontroleri.*;

import java.io.IOException;

public sealed interface GlavnoSucelje permits SuceljeAdminController, SuceljeModController, SuceljeUserController, PotragaKnjigaSucelje {
    Stage potragaKnjigaStage = new Stage();
    Stage objavaKnjigeStage = new Stage();
    Stage ovjeraStage = new Stage();
    Stage mojeKnjigeStage = new Stage();

    default void showPotragaKnjigaKorisnikScreen(String username) throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("potragaKnjigaUser.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            potragaKnjigaStage.setTitle("Potraga knjiga");
            potragaKnjigaStage.setScene(scene);
            potragaKnjigaStage.setResizable(false);
            PotragaKnjigaUserController potragaController = fxmlLoader.getController();
            potragaController.postaviUsername(username);
            potragaKnjigaStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    default void showPotragaKnjigaDjelatnikScreen(String username) throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("potragaKnjigaMod.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            potragaKnjigaStage.setTitle("Potraga knjiga");
            potragaKnjigaStage.setScene(scene);
            potragaKnjigaStage.setResizable(false);
            PotragaKnjigaModController potragaController = fxmlLoader.getController();
            potragaController.postaviUsername(username);
            potragaKnjigaStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    default void showObjavaKnjigeScreen(String username) throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("objavaKnjige.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            objavaKnjigeStage.setTitle("Objava knjige");
            objavaKnjigeStage.setScene(scene);
            objavaKnjigeStage.setResizable(false);
            ObjavaKnjigeController objavaController = fxmlLoader.getController();
            objavaController.postaviUsername(username);
            objavaKnjigeStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    default void showOvjeraScreen(String username) throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("ovjera.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            ovjeraStage.setTitle("Ovjera");
            ovjeraStage.setScene(scene);
            ovjeraStage.setResizable(false);
            OvjeraController ovjeraController = fxmlLoader.getController();
            ovjeraController.mjenjac = username;
            ovjeraStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    default void showMojeKnjigeScreen() throws FXMLLoaderException {
        FXMLLoaderSpajanje.spoji("mojeKnjige.fxml", "Moje knjige", mojeKnjigeStage);
    }

    default void showKorisnickaPrijavaScreen() throws FXMLLoaderException {
        FXMLLoaderSpajanje.spoji("prijava.fxml", "Korisnička Prijava", AkademskiRepozitorij.getMainStage());
    }
}
