package sucelja;

import baza.BazaPodataka;
import dodatno.FXMLLoaderSpajanje;
import glavna.AkademskiRepozitorij;
import iznimke.DBPropertyException;
import iznimke.FXMLLoaderException;
import iznimke.QueryException;
import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import static glavna.AkademskiRepozitorij.logger;

public interface RegistracijaSucelje {
    default void showKorisnickaPrijavaScreen() throws FXMLLoaderException {
        FXMLLoaderSpajanje.spoji("prijava.fxml", "Korisnička Prijava", AkademskiRepozitorij.getMainStage());
    }

    default void registracijaKorisnika(String jmbag, String ime, String prezime, String email, String lozinka, LocalDate datumRodjenja) throws QueryException {
        boolean jmbagNull = jmbag.isBlank();
        boolean imeNull = ime.isBlank();
        boolean prezimeNull = prezime.isBlank();
        boolean emailNull = email.isBlank();
        boolean lozinkaNull = lozinka.isBlank();
        boolean datumRodjenjaNull = datumRodjenja.equals(LocalDate.of(2025, 1, 1));

        if (!jmbagNull & !imeNull & !prezimeNull & !emailNull & !lozinkaNull & !datumRodjenjaNull) {
            try (Connection veza = BazaPodataka.connectToDatabase(); PreparedStatement stmt = veza.prepareStatement("SELECT * FROM KORISNIK WHERE email = ?")) {
                stmt.setString(1, email);
                ResultSet rs = stmt.executeQuery();

                if (!rs.next()) {
                    BazaPodataka.unesiKorisnikaOvjeriti(jmbag, ime, prezime, email, lozinka, datumRodjenja);
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Spremanje korisnika");
                    alert.setHeaderText("Neuspješno registriranje");
                    alert.setContentText("Taj e-mail je već u uporabi!");
                    alert.show();
                }
            } catch (SQLException sqlException) {
                throw new QueryException(sqlException.getMessage(), sqlException.getCause());
            } catch (DBPropertyException e) {
                logger.warn(e.getMessage(), e.getCause());
            }
        } else {
            String content = "";

            if (jmbagNull) content += "Nedostaje jmbag\n";
            if (imeNull) content += "Nedostaje ime\n";
            if (prezimeNull) content += "Nedostaje prezime\n";
            if (emailNull) content += "Nedostaje email\n";
            if (lozinkaNull) content += "Nedostaje lozinka\n";
            if (datumRodjenjaNull) content += "Nedostaje datum rođenja";

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Spremanje korisnika");
            alert.setHeaderText("Neuspješno registriranje");
            alert.setContentText(content);
            alert.show();
        }
    }
}
