package sucelja;

import dodatno.FXMLLoaderSpajanje;
import dodatno.PasswordHasher;
import glavna.AkademskiRepozitorij;
import iznimke.NeuspjelaPrijavaException;
import iznimke.QueryException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import kontroleri.SuceljeAdminController;
import kontroleri.SuceljeModController;
import kontroleri.SuceljeUserController;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static baza.BazaPodataka.connectToDatabase;
import static glavna.AkademskiRepozitorij.logger;

public interface PrijavaSucelje {
    int BROJ_ZAPISA_GOSTA = 3;
    int BROJ_ZAPISA_DJELATNIKA = 6;
    Path datoteka = Paths.get("src/main/resources/dat/dozvole.txt");
    Path djelatnici = Paths.get("src/main/resources/dat/djelatnici.txt");

    default void showRegistracijaScreen() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("registracija.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        AkademskiRepozitorij.getMainStage().setTitle("Registracija");
        AkademskiRepozitorij.getMainStage().setScene(scene);
        AkademskiRepozitorij.getMainStage().show();
    }

    default void showSuceljeScreen(String korisnickoIme, String lozinka) throws QueryException, NeuspjelaPrijavaException {
        boolean korisnickiPodaciIspravni = false;
        String hashLozinka = PasswordHasher.hashPassword(lozinka);
        //surfanje po djelatnicima
        try (BufferedReader in = new BufferedReader(new FileReader(djelatnici.toFile()))) {
            List<String> datotekaDjelatnika = in.lines().toList();
            for (int i = 0; i < datotekaDjelatnika.size() / BROJ_ZAPISA_DJELATNIKA; i++) {
                String usporedba = datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA + 4);
                if (korisnickoIme.equals(datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA)) && (lozinka.equals(usporedba) || hashLozinka.equals(usporedba))) {

                    //admin login
                    if (datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA + 5).equals("administrator")) {
                        FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("suceljeAdmin.fxml"));
                        Scene scene = new Scene(fxmlLoader.load());
                        korisnickiPodaciIspravni = true;
                        FXMLLoaderSpajanje.spoji("suceljeAdmin.fxml", "Dobrodošli!", AkademskiRepozitorij.getMainStage());

                        SuceljeAdminController adminController = fxmlLoader.getController();
                        String ime = datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA + 1);
                        String prezime = datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA + 2);
                        adminController.postaviIme(ime);
                        adminController.postaviPrezime(prezime);
                        adminController.postaviRolu("Administrator");
                        adminController.postaviUsername(korisnickoIme);

                        AkademskiRepozitorij.getMainStage().setScene(scene);
                    } //mod login
                    else {
                        FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("suceljeMod.fxml"));
                        Scene scene = new Scene(fxmlLoader.load());
                        korisnickiPodaciIspravni = true;
                        SuceljeModController modController = fxmlLoader.getController();

                        String ime = datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA + 1);
                        String prezime = datotekaDjelatnika.get(i * BROJ_ZAPISA_DJELATNIKA + 2);
                        modController.postaviIme(ime);
                        modController.postaviPrezime(prezime);
                        modController.postaviRolu("Moderator");
                        modController.postaviUsername(korisnickoIme);

                        AkademskiRepozitorij.getMainStage().setScene(scene);
                    }

                    AkademskiRepozitorij.getMainStage().setTitle("Dobrodošli!");
                    AkademskiRepozitorij.getMainStage().setResizable(false);
                    AkademskiRepozitorij.getMainStage().show();
                    break;
                }
            }
        } catch (IOException ioException) {
            logger.error(ioException.getMessage(), ioException.getCause());
        }

        //surfanje po gostima
        try (FileReader fr = new FileReader(datoteka.toFile()); BufferedReader in = new BufferedReader(fr)) {

            List<String> datotekaDozvola = in.lines().toList();

            for (int i = 0; i < datotekaDozvola.size() / BROJ_ZAPISA_GOSTA; i++) {
                String usporedba = datotekaDozvola.get(i * BROJ_ZAPISA_GOSTA + 1);
                if (korisnickoIme.equals(datotekaDozvola.get(i * BROJ_ZAPISA_GOSTA)) && lozinka.equals(usporedba) || hashLozinka.equals(usporedba)) {
                    FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("suceljeUser.fxml"));
                    Scene scene = new Scene(fxmlLoader.load());
                    korisnickiPodaciIspravni = true;
                    SuceljeUserController korisnikController = fxmlLoader.getController();
                    try (Connection veza = connectToDatabase(); PreparedStatement stmt = veza.prepareStatement("SELECT * FROM KORISNIK WHERE korisnicko_ime = ?")) {
                        stmt.setString(1, korisnickoIme);
                        ResultSet rs = stmt.executeQuery();

                        String username = null;

                        if (rs.next()) {
                            username = rs.getString("korisnicko_ime");
                        }
                        korisnikController.postaviUsername(username);
                        if (datotekaDozvola.get(i * BROJ_ZAPISA_GOSTA + 2).equals("osnovnoskolac"))
                            korisnikController.postaviRolu("Osnovnoškolac");
                        if (datotekaDozvola.get(i * BROJ_ZAPISA_GOSTA + 2).equals("srednjoskolac"))
                            korisnikController.postaviRolu("Srednjoškolac");
                        if (datotekaDozvola.get(i * BROJ_ZAPISA_GOSTA + 2).equals("akademik"))
                            korisnikController.postaviRolu("Akademik");

                        AkademskiRepozitorij.getMainStage().setTitle("Dobrodošli");
                        AkademskiRepozitorij.getMainStage().setScene(scene);
                        AkademskiRepozitorij.getMainStage().show();
                        break;
                    } catch (SQLException sqlException) {
                        throw new QueryException(sqlException.getMessage(), sqlException.getCause());
                    }
                }
            }
        } catch (IOException ioException) {
            logger.error(ioException.getMessage(), ioException.getCause());
        }
        if (!korisnickiPodaciIspravni) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Pogreška");
            alert.setHeaderText(null);
            alert.setContentText("Korisničko ime i/ili lozinka nisu nisu ispravni!");
            alert.showAndWait();
            throw new NeuspjelaPrijavaException();
        }
    }
}
