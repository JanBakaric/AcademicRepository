package sucelja;

import entiteti.Knjiga;
import glavna.AkademskiRepozitorij;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import kontroleri.*;

import java.io.IOException;

public sealed interface PotragaKnjigaSucelje extends GlavnoSucelje permits MojeKnjigeController, PotragaKnjigaModController, PotragaKnjigaUserController {
    default void showOpisKnjigeDjelatnikScreen(Knjiga knjiga, String username) throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("opisKnjigeMod.fxml"));
            Parent root = fxmlLoader.load();

            OpisKnjigeModController controller = fxmlLoader.getController();
            controller.postaviNaziv(knjiga.getNaziv());
            controller.postaviAutora(knjiga.getImeAutora(), knjiga.getPrezimeAutora());
            controller.postaviGodinuIzdanja(knjiga.getGodinaIzdanja());
            controller.postaviZemljuPorijekla(knjiga.getZemljaPorijekla());
            controller.postaviIzdavaca(knjiga.getIzdavac());
            controller.postaviTipDjela(knjiga.getTipKnjige().toString());
            controller.postaviObjavitelja(knjiga.getObjavitelj());
            controller.setPutanja(knjiga.getPutanja());
            controller.setID(knjiga.getId());
            OpisKnjigeModController.knjigaZaIzmjenu = knjiga;
            controller.setUsername(username);

            Stage opisKnjigeStage = new Stage();
            opisKnjigeStage.setTitle("Opis knjige");
            opisKnjigeStage.setScene(new Scene(root));
            opisKnjigeStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    default void showOpisKnjigeKorisnikScreen(Knjiga knjiga) throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("opisKnjigeUser.fxml"));
            Parent root = fxmlLoader.load();

            OpisKnjigeUserController controller = fxmlLoader.getController();
            controller.postaviNaziv(knjiga.getNaziv());
            controller.postaviAutora(knjiga.getImeAutora(), knjiga.getPrezimeAutora());
            controller.postaviGodinuIzdanja(knjiga.getGodinaIzdanja());
            controller.postaviZemljuPorijekla(knjiga.getZemljaPorijekla());
            controller.postaviIzdavaca(knjiga.getIzdavac());
            controller.postaviTipDjela(knjiga.getTipKnjige().toString());
            controller.postaviObjavitelja(knjiga.getObjavitelj());
            controller.setPutanja(knjiga.getPutanja());

            Stage opisKnjigeStage = new Stage();
            opisKnjigeStage.setTitle("Opis knjige");
            opisKnjigeStage.setScene(new Scene(root));
            opisKnjigeStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }
}