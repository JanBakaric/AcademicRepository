package kontroleri;

import dodatno.AppendableObjectInputStream;
import entiteti.IzmjenaKnjige;
import iznimke.DeserijalizacijaException;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Duration;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static glavna.AkademskiRepozitorij.logger;

public class OvjeraIzmjenaKnjigaController {
    private final Object lock = new Object();
    @FXML
    TableView<IzmjenaKnjige> knjigaTableView;
    @FXML
    TableColumn<IzmjenaKnjige, String> stariNazivTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> noviNazivTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> staroImeAutoraTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> novoImeAutoraTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> staroPrezimeAutoraTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> novoPrezimeAutoraTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> staraGodinaIzdanjaTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> novaGodinaIzdanjaTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> staraZemljaPorijeklaTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> novaZemljaPorijeklaTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> stariIzdavacTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> noviIzdavacTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> vrstaDjelaTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> djelatnikTableColumn;
    @FXML
    TableColumn<IzmjenaKnjige, String> vrijemeIzmjeneTableColumn;

    @FXML
    void initialize() throws DeserijalizacijaException {
        ObservableList<IzmjenaKnjige> izmjeneDat = FXCollections.observableList(dohvatiIzmjene());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

        knjigaTableView.setItems(izmjeneDat);
        stariNazivTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStariNaziv()));
        noviNazivTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNaziv()));
        staroImeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStaroImeAutora()));
        novoImeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getImeAutora()));
        staroPrezimeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStaroPrezimeAutora().toString()));
        novoPrezimeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrezimeAutora()));
        staraGodinaIzdanjaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStaraGodinaIzdanja()));
        novaGodinaIzdanjaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getGodinaIzdanja()));
        staraZemljaPorijeklaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStaraZemljaPorijekla()));
        novaZemljaPorijeklaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getZemljaPorijekla()));
        stariIzdavacTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStariIzdavac()));
        noviIzdavacTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getIzdavac()));
        vrstaDjelaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTipKnjige() != null ? data.getValue().getTipKnjige().toString() : "nez"));
        djelatnikTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMjenjac()));
        vrijemeIzmjeneTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getVrijemeIzmjene().format(formatter)));

        Timeline osvjeziTimeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            izmjeneDat.clear();
            try {
                izmjeneDat.addAll(dohvatiIzmjene());
            } catch (DeserijalizacijaException ex) {
                logger.error(ex.getMessage(), ex.getCause());
            }
            knjigaTableView.setItems(izmjeneDat);
        }));
        osvjeziTimeline.setCycleCount(Timeline.INDEFINITE);
        osvjeziTimeline.play();
    }

    public ArrayList<IzmjenaKnjige> dohvatiIzmjene() throws DeserijalizacijaException {
        ArrayList<IzmjenaKnjige> izmjene = new ArrayList<>();

        synchronized (lock) {
            try (FileInputStream fin = new FileInputStream("src/main/resources/dat/izmjeneNadKnjigama.dat"); AppendableObjectInputStream oin = new AppendableObjectInputStream(fin)) {
                while (true) {
                    try {
                        IzmjenaKnjige izmjena = (IzmjenaKnjige) oin.readObject();
                        izmjene.add(izmjena);
                    } catch (EOFException eofException) {
                        logger.info("Deserijalizirane izmjene!");
                        break;
                    }
                }
            } catch (IOException ioException) {
                throw new DeserijalizacijaException(ioException.getMessage(), ioException.getCause());
            } catch (ClassNotFoundException e) {
                logger.warn(e.getMessage(), e.getCause());
            }
        }

        return izmjene;
    }
}
