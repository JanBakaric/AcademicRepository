package kontroleri;

import baza.BazaPodataka;
import entiteti.Gost;
import glavna.AkademskiRepozitorij;
import iznimke.DBPropertyException;
import iznimke.FXMLLoaderException;
import iznimke.SpajanjeNaBazuException;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public class OvjeraKorisnikaController {
    public static String mjenjac;
    static Stage korisnikStage = new Stage();
    @FXML
    Button pogledajKorisnikaButton;
    @FXML
    TableView<Gost> korisnikTableView;
    @FXML
    TableColumn<Gost, String> imeKorisnikaTableColumn;
    @FXML
    TableColumn<Gost, String> prezimeKorisnikaTableColumn;
    @FXML
    TableColumn<Gost, String> datumRodjenjaKorisnikaTableColumn;
    @FXML
    TableColumn<Gost, String> jmbagKorisnikaTableColumn;
    @FXML
    Label usernameLabel;

    Gost korisnik;

    public static Stage getStage() {
        return korisnikStage;
    }

    @FXML
    void initialize() throws SpajanjeNaBazuException, DBPropertyException {
        ObservableList<Gost> korisnici = FXCollections.observableList(BazaPodataka.dohvatiKorisnike());

        korisnikTableView.setItems(korisnici);
        imeKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getIme()));
        prezimeKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrezime()));
        datumRodjenjaKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getDatumRodjenja().toString()));
        jmbagKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getJmbag()));

        korisnikTableView.getSelectionModel().selectedItemProperty().addListener((observableValue, stariOdabir, noviOdabir) -> {
            korisnik = noviOdabir;
        });

        Timeline osvjeziTimeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            korisnici.clear();
            try {
                korisnici.addAll(BazaPodataka.dohvatiKorisnike());
            } catch (SpajanjeNaBazuException | DBPropertyException ex) {
                logger.error(ex.getMessage(), ex.getCause());
            }
            korisnikTableView.setItems(korisnici);
        }));
        osvjeziTimeline.setCycleCount(Timeline.INDEFINITE);
        osvjeziTimeline.play();
    }

    public void ovjeriKorisnika() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("userOvjera.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            if (korisnik != null) {
                UserOvjeraController korisnikController = fxmlLoader.getController();
                korisnikController.unesiImeIPrezime(korisnik.getIme(), korisnik.getPrezime());
                korisnikController.unesiDatumRodjenjaIDob(korisnik.getDatumRodjenja());
                korisnikController.unesiJMBAG(korisnik.getJmbag());
                korisnikController.unesiEmail(korisnik.getEmail());

                UserOvjeraController.korisnikZaOvjeru = korisnik;

                korisnikStage.setTitle("Ovjeravanje korisnika");
                korisnikStage.setScene(scene);
                korisnikStage.setResizable(false);
                korisnikStage.show();
                korisnikController.postaviUsername(usernameLabel.getText());
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Neoznačen korisnik");
                alert.setHeaderText("Neoznačen korisnik");
                alert.setContentText("Odaberite korisnika iz tablice prije nego što nastavite!");
                alert.show();
            }
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }
}
