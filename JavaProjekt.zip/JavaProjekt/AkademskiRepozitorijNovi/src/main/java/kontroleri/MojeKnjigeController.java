package kontroleri;

import entiteti.Knjiga;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import sucelja.PotragaKnjigaSucelje;

import static glavna.AkademskiRepozitorij.logger;

public final class MojeKnjigeController implements PotragaKnjigaSucelje {
    @FXML
    Button pogledajKnjiguButton;

    @FXML
    public void initialize() {
        Knjiga knjiga = null;
        pogledajKnjiguButton.setOnAction(e -> {
            try {
                showOpisKnjigeKorisnikScreen(knjiga);
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
    }

}
