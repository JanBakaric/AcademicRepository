package kontroleri;

import baza.BazaPodataka;
import dodatno.AppendableObjectOutputStream;
import dodatno.PasswordHasher;
import entiteti.Gost;
import entiteti.IzmjenaKorisnika;
import iznimke.DBPropertyException;
import iznimke.QueryException;
import iznimke.SerijalizacijaException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;

import static glavna.AkademskiRepozitorij.logger;

public class UserOvjeraController {
    public static Gost korisnikZaOvjeru;
    Path datoteka = Paths.get("src/main/resources/dat/dozvole.txt");
    Path djelatnici = Paths.get("src/main/resources/dat/djelatnici.txt");
    Path izmjene = Paths.get("src/main/resources/dat/izmjeneNadKorisnicima.dat");
    Stage stage = OvjeraKorisnikaController.getStage();
    @FXML
    Label imePrezimeLabel, datumRodjenjaLabel, dobLabel, jmbagLabel, emailLabel, usernameLabel;
    @FXML
    Button odobriButton;
    @FXML
    Button odbijButton;
    ToggleGroup rola = new ToggleGroup();

    @FXML
    RadioButton admin;
    @FXML
    RadioButton mod;

    @FXML
    private void initialize() {
        admin.setToggleGroup(rola);
        mod.setToggleGroup(rola);
    }

    public void unesiImeIPrezime(String ime, String prezime) {
        imePrezimeLabel.setText(ime + " " + prezime);
    }

    public void unesiDatumRodjenjaIDob(LocalDate datumRodjenja) {
        datumRodjenjaLabel.setText(datumRodjenja.toString());
        dobLabel.setText(String.valueOf(Period.between(datumRodjenja, LocalDate.now()).getYears()));
    }

    public void unesiJMBAG(String jmbag) {
        jmbagLabel.setText(jmbag);
    }

    public void unesiEmail(String email) {
        emailLabel.setText(email);
    }

    public synchronized void odobri() throws SerijalizacijaException, QueryException {
        try (Connection veza = BazaPodataka.connectToDatabase()) {
            veza.setAutoCommit(false);
            String lozinka = PasswordHasher.hashPassword(korisnikZaOvjeru.getLozinka());

            if (admin.isSelected() | mod.isSelected()) {    //zapis u djelatnike
                try (FileWriter fw = new FileWriter(djelatnici.toFile(), true); PrintWriter pw = new PrintWriter(fw)) {
                    pw.append("\n").append(korisnikZaOvjeru.getKorisnickoIme()).append("\n").append(korisnikZaOvjeru.getIme()).append("\n").append(korisnikZaOvjeru.getPrezime()).append("\n").append(String.valueOf(korisnikZaOvjeru.getDatumRodjenja())).append("\n").append(lozinka).append("\n").append(admin.isSelected() ? "administrator" : "moderator");
                    pw.flush();
                } catch (IOException ioException) {
                    logger.error(ioException.getMessage(), ioException.getCause());
                }
                PreparedStatement stmt;
                stmt = veza.prepareStatement("DELETE FROM KORISNICI_ZA_OVJERU WHERE id = ?");
                stmt.setInt(1, korisnikZaOvjeru.getId());
                stmt.executeUpdate();
            } else {    //zapis u korisnike
                PreparedStatement stmt;
                stmt = veza.prepareStatement("DELETE FROM KORISNICI_ZA_OVJERU WHERE id = ?");
                stmt.setInt(1, korisnikZaOvjeru.getId());
                stmt.executeUpdate();

                PreparedStatement stmt1;
                stmt1 = veza.prepareStatement("INSERT INTO KORISNIK (jmbag, ime, prezime, datum_rodjenja, korisnicko_ime, email) VALUES (?, ?, ?, ?, ?, ?)");
                stmt1.setString(1, korisnikZaOvjeru.getJmbag());
                stmt1.setString(2, korisnikZaOvjeru.getIme());
                stmt1.setString(3, korisnikZaOvjeru.getPrezime());
                stmt1.setString(4, korisnikZaOvjeru.getDatumRodjenja().toString());
                stmt1.setString(5, korisnikZaOvjeru.getKorisnickoIme());
                stmt1.setString(6, korisnikZaOvjeru.getEmail());
                stmt.executeUpdate();

                String dozvola;
                int dob = Period.between(korisnikZaOvjeru.getDatumRodjenja(), LocalDate.now()).getYears();
                if (dob < 14) {
                    dozvola = "osnovnoskolac";
                } else if (dob < 18) {
                    dozvola = "srednjoskolac";
                } else {
                    dozvola = "akademik";
                }
                try (FileWriter fw = new FileWriter(datoteka.toString(), StandardCharsets.UTF_8, true); PrintWriter pw = new PrintWriter(fw)) {
                    pw.append("\n").append(korisnikZaOvjeru.getKorisnickoIme()).append("\n").append(lozinka).append("\n").append(dozvola);
                    pw.flush();
                } catch (IOException ioException) {
                    logger.warn(ioException.getMessage(), ioException.getCause());
                }
            }
            veza.commit();
            veza.setAutoCommit(true);

            try (FileOutputStream fw = new FileOutputStream(izmjene.toString(), true); AppendableObjectOutputStream out = new AppendableObjectOutputStream(fw)) {
                out.writeObject(new IzmjenaKorisnika(korisnikZaOvjeru, LocalDateTime.now(), usernameLabel.getText()));
            } catch (IOException ioException) {
                throw new SerijalizacijaException(ioException.getMessage(), ioException.getCause());
            }

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Spremanje korisnika");
            alert.setHeaderText("Uspješno dodan korisnik");
            alert.setContentText("Dodan korisnik " + korisnikZaOvjeru.getIme() + " " + korisnikZaOvjeru.getPrezime());
            alert.show();

            stage.close();
        } catch (SQLException sqlException) {
            throw new QueryException(sqlException.getMessage(), sqlException.getCause());
        } catch (DBPropertyException e) {
            logger.warn(e.getMessage(), e.getCause());
        }
    }

    public synchronized void odbij() throws QueryException {
        PreparedStatement stmt;
        try (Connection veza = BazaPodataka.connectToDatabase()) {
            if (veza != null) {
                stmt = veza.prepareStatement("DELETE FROM KORISNICI_ZA_OVJERU WHERE id = ?");
                stmt.setInt(1, korisnikZaOvjeru.getId());
                stmt.executeUpdate();
            }

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Spremanje korisnika");
            alert.setHeaderText("Odbaćen korisnik");
            alert.setContentText("Odbaćen korisnik " + korisnikZaOvjeru.getIme() + " " + korisnikZaOvjeru.getPrezime());
            alert.show();

            stage.close();
        } catch (SQLException sqlException) {
            throw new QueryException(sqlException.getMessage(), sqlException.getCause());
        } catch (DBPropertyException e) {
            logger.warn(e.getMessage(), e.getCause());
        }
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }
}
