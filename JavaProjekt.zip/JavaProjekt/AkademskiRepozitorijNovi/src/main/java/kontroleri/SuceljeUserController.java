package kontroleri;

import glavna.AkademskiRepozitorij;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import sucelja.GlavnoSucelje;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public non-sealed class SuceljeUserController implements GlavnoSucelje {
    Stage mojProfilStage = new Stage();
    @FXML
    private Button potraziKnjiguButton;
    @FXML
    private Button objaviKnjiguButton;
    @FXML
    private Button mojProfilButton;
    @FXML
    private Button odjaviMeButton;
    @FXML
    private Label razinaOvlastiLabel;
    @FXML
    private Label usernameLabel;

    @FXML
    void initialize() {
        potraziKnjiguButton.setOnAction(e -> {
            try {
                showPotragaKnjigaKorisnikScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        objaviKnjiguButton.setOnAction(e -> {
            try {
                showObjavaKnjigeScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        mojProfilButton.setOnAction(e -> {
            try {
                showMojProfilScreen();
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        odjaviMeButton.setOnAction(e -> {
            try {
                showKorisnickaPrijavaScreen();
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
    }

    public void postaviRolu(String rola) {
        razinaOvlastiLabel.setText(rola);
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }

    public void showMojProfilScreen() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("mojProfil.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            mojProfilStage.setTitle("Moj profil");
            mojProfilStage.setScene(scene);
            mojProfilStage.setResizable(false);
            MojProfilController mojProfilController = fxmlLoader.getController();
            mojProfilController.setKorisnik(usernameLabel.getText());
            mojProfilStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }
}
