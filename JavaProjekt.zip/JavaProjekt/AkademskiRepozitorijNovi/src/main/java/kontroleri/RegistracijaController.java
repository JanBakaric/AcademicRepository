package kontroleri;

import iznimke.FXMLLoaderException;
import iznimke.QueryException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import sucelja.RegistracijaSucelje;

import java.time.LocalDate;

import static glavna.AkademskiRepozitorij.logger;

public class RegistracijaController implements RegistracijaSucelje {
    @FXML
    Button nazadButton;
    @FXML
    Button registrirajMeButton;
    @FXML
    TextField imeTextField;
    @FXML
    TextField prezimeTextField;
    @FXML
    TextField jmbagTextField;
    @FXML
    TextField emailTextField;
    @FXML
    TextField lozinkaTextField;
    @FXML
    DatePicker datumRodjenjaDatePicker;

    @FXML
    void initialize() {
        nazadButton.setOnAction(e -> {
            try {
                showKorisnickaPrijavaScreen();
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        registrirajMeButton.setOnAction(e -> {
            LocalDate defDatum = LocalDate.of(2025, 1, 1);

            if (datumRodjenjaDatePicker.getValue() != null) {
                try {
                    registracijaKorisnika(jmbagTextField.getText(), imeTextField.getText(), prezimeTextField.getText(), emailTextField.getText(), lozinkaTextField.getText(), datumRodjenjaDatePicker.getValue());
                } catch (QueryException ex) {
                    logger.warn(ex.getMessage(), ex.getCause());
                }
            } else {
                try {
                    registracijaKorisnika(jmbagTextField.getText(), imeTextField.getText(), prezimeTextField.getText(), emailTextField.getText(), lozinkaTextField.getText(), defDatum);
                } catch (QueryException ex) {
                    logger.warn(ex.getMessage(), ex.getCause());
                }
            }

            imeTextField.clear();
            prezimeTextField.clear();
            jmbagTextField.clear();
            emailTextField.clear();
            lozinkaTextField.clear();
            datumRodjenjaDatePicker.setValue(null);
            try {
                showKorisnickaPrijavaScreen();
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
    }
}
