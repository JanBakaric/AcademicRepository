package kontroleri;

import baza.BazaPodataka;
import dodatno.AppendableObjectOutputStream;
import dodatno.Preuzimanje;
import entiteti.IzmjenaKnjige;
import entiteti.Knjiga;
import glavna.AkademskiRepozitorij;
import iznimke.FXMLLoaderException;
import iznimke.PreuzimanjeException;
import iznimke.QueryException;
import iznimke.SerijalizacijaException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

import static glavna.AkademskiRepozitorij.logger;

public class OpisKnjigeModController extends Preuzimanje {
    public static Knjiga knjigaZaIzmjenu;
    private final Object lock = new Object();
    private final ToggleGroup ocjene = new ToggleGroup();
    Stage izmijeniStage = new Stage();
    Path izmjene = Path.of("src/main/resources/dat/izmjeneNadKnjigama.dat");
    private String putanja;
    private String username;
    private int ID;
    @FXML
    private RadioButton ocjena1, ocjena2, ocjena3, ocjena4, ocjena5;
    @FXML
    private Button preuzmiButton;
    @FXML
    private Button preuzmiIOtvoriButton;
    @FXML
    private Label nazivLabel;
    @FXML
    private Label autorLabel;
    @FXML
    private Label godinaIzdanjaLabel;
    @FXML
    private Label zemljaPorijeklaLabel;
    @FXML
    private Label izdavacLabel;
    @FXML
    private Label tipDjelaLabel;
    @FXML
    private Label prosjecnaOcjenaLabel;
    @FXML
    private Label objaviteljLabel;

    public static void serijalizacijaIzmjene(IzmjenaKnjige izmjena, Path izmjene) {
        try (FileOutputStream fw = new FileOutputStream(izmjene.toString(), true); AppendableObjectOutputStream out = new AppendableObjectOutputStream(fw)) {
            out.writeObject(izmjena);
        } catch (IOException ioException) {
            try {
                throw new SerijalizacijaException(ioException.getMessage(), ioException.getCause());
            } catch (SerijalizacijaException e) {
                logger.warn(e.getMessage(), e.getCause());
            }
        }
    }

    @FXML
    private void initialize() {
        grupiraj(ocjena1, ocjene, ocjena2, ocjena3, ocjena4, ocjena5, prosjecnaOcjenaLabel, preuzmiButton, putanja, preuzmiIOtvoriButton);
    }

    public static void grupiraj(RadioButton ocjena1, ToggleGroup ocjene, RadioButton ocjena2, RadioButton ocjena3, RadioButton ocjena4, RadioButton ocjena5, Label prosjecnaOcjenaLabel, Button preuzmiButton, String putanja, Button preuzmiIOtvoriButton) {
        ocjena1.setToggleGroup(ocjene);
        ocjena2.setToggleGroup(ocjene);
        ocjena3.setToggleGroup(ocjene);
        ocjena4.setToggleGroup(ocjene);
        ocjena5.setToggleGroup(ocjene);
        prosjecnaOcjenaLabel.setVisible(false);

        preuzimanje(preuzmiButton, putanja, preuzmiIOtvoriButton);
    }

    public static void preuzimanje(Button preuzmiButton, String putanja, Button preuzmiIOtvoriButton) {
        preuzmiButton.setOnAction(event -> {
            try {
                Preuzimanje.preuzmi((Stage) preuzmiButton.getScene().getWindow(), putanja);
            } catch (PreuzimanjeException e) {
                logger.warn(e.getMessage(), e.getCause());
            }
        });
        preuzmiIOtvoriButton.setOnAction(event -> {
            try {
                Preuzimanje.preuzmiIOtvori((Stage) preuzmiButton.getScene().getWindow(), putanja);
            } catch (PreuzimanjeException e) {
                logger.warn(e.getMessage(), e.getCause());
            }
        });
    }

    public void postaviNaziv(String naziv) {
        nazivLabel.setText(naziv);
    }

    public void postaviAutora(String ime, String prezime) {
        autorLabel.setText(ime + " " + prezime);
    }

    public void postaviGodinuIzdanja(String godinaIzdanja) {
        godinaIzdanjaLabel.setText(godinaIzdanja);
    }

    public void postaviZemljuPorijekla(String zemljaPorijekla) {
        zemljaPorijeklaLabel.setText(zemljaPorijekla);
    }

    public void postaviIzdavaca(String izdavac) {
        izdavacLabel.setText(izdavac);
    }

    public void postaviTipDjela(String tipDjela) {
        tipDjelaLabel.setText(tipDjela);
    }

    public void postaviObjavitelja(String objavitelj) {
        objaviteljLabel.setText(objavitelj);
    }

    public void postaviProsjecnuOcjenu(String prosjecnaOcjena) {
        prosjecnaOcjenaLabel.setText(prosjecnaOcjena);
    }

    public void setPutanja(String putanja) {
        this.putanja = putanja;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void showIzmijeniScreen() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("Izmijeni.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            izmijeniStage.setTitle("Izmjena knjige");
            izmijeniStage.setScene(scene);
            izmijeniStage.setResizable(false);
            IzmijeniController izmijeniController = fxmlLoader.getController();
            izmijeniController.postaviUsername(username);
            izmijeniController.knjigaZaIzmjenu = knjigaZaIzmjenu;
            izmijeniStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    public void ukloni() {
        ButtonType yesButton = new ButtonType("Da");
        ButtonType noButton = new ButtonType("Ne");

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Brisanje knjige");
        alert.setHeaderText("Jeste li sigurni da želite ukloniti knjigu s repozitorija?");
        alert.setContentText("Uklanjanjem knjige ćete ju nepovratno ukloniti s repozitorija.");
        alert.getButtonTypes().setAll(yesButton, noButton);
        alert.showAndWait().ifPresent(buttonType -> {
            if (buttonType == yesButton) {
                synchronized (lock) {
                    try (Connection veza = BazaPodataka.connectToDatabase(); PreparedStatement stmt = veza.prepareStatement("DELETE FROM KNJIGA WHERE ID = ?")) {
                        stmt.setInt(1, ID);
                        stmt.executeUpdate();

                        IzmjenaKnjige izmjena = new IzmjenaKnjige();
                        izmjena.setStariNaziv(knjigaZaIzmjenu.getNaziv());
                        izmjena.setStaroImeAutora(knjigaZaIzmjenu.getImeAutora());
                        izmjena.setStaroPrezimeAutora(knjigaZaIzmjenu.getPrezimeAutora());
                        izmjena.setStaraGodinaIzdanja(knjigaZaIzmjenu.getGodinaIzdanja());
                        izmjena.setStaraZemljaPorijekla(knjigaZaIzmjenu.getZemljaPorijekla());
                        izmjena.setStariIzdavac(knjigaZaIzmjenu.getIzdavac());
                        izmjena.setTipKnjige(knjigaZaIzmjenu.getTipKnjige());
                        izmjena.setPutanja(knjigaZaIzmjenu.getPutanja());
                        izmjena.setObjavitelj(knjigaZaIzmjenu.getObjavitelj());
                        izmjena.setVrijemeIzmjene(LocalDateTime.now());
                        izmjena.setMjenjac(username);

                        serijalizacijaIzmjene(izmjena, izmjene);
                        Files.deleteIfExists(Path.of(knjigaZaIzmjenu.getPutanja()));
                        Stage stage = (Stage) nazivLabel.getScene().getWindow();
                        stage.close();
                    } catch (SQLException sqlException) {
                        try {
                            throw new QueryException(sqlException.getMessage(), sqlException.getCause());
                        } catch (QueryException e) {
                            logger.warn(e.getMessage(), e.getCause());
                        }
                    } catch (IOException e) {
                        logger.warn(e.getMessage(), e.getCause());
                    }
                }
            }
        });
    }
}