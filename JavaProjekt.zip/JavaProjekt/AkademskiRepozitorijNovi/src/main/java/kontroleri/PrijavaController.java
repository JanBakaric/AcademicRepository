package kontroleri;

import iznimke.FXMLLoaderException;
import iznimke.NeuspjelaPrijavaException;
import iznimke.QueryException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import sucelja.PrijavaSucelje;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public class PrijavaController implements PrijavaSucelje {
    public static String korisnickoIme;
    public static String lozinka;
    @FXML
    private TextField korisnickoImeTextField;
    @FXML
    private PasswordField lozinkaPasswordField;
    @FXML
    private Button prijaviSeButton, registrirajSeButton;

    @FXML
    void initialize() {
        prijaviSeButton.setOnAction(e -> {
            try {
                showSuceljeScreen(korisnickoImeTextField.getText(), lozinkaPasswordField.getText());
            } catch (QueryException | NeuspjelaPrijavaException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        registrirajSeButton.setOnAction(e -> {
            try {
                showRegistracijaScreen();
            } catch (IOException ioException) {
                try {
                    throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
                } catch (FXMLLoaderException ex) {
                    logger.warn(ex.getMessage(), ex.getCause());
                }
            }
        });
    }
}