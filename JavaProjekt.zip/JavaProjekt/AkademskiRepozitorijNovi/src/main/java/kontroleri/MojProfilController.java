package kontroleri;

import baza.BazaPodataka;
import iznimke.DBPropertyException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;

import static glavna.AkademskiRepozitorij.logger;

public class MojProfilController {
    @FXML
    Button unesiButton;
    @FXML
    Label imePrezimeLabel;
    @FXML
    Label datumRodjenjaLabel;
    @FXML
    Label jmbagLabel;
    @FXML
    Label razinaOvlastiLabel;


    public void predajDodatneInformacije() {
        Stage stage = (Stage) unesiButton.getScene().getWindow();
        stage.close();
    }

    public void setKorisnik(String korisnik) {
        try (Connection veza = BazaPodataka.connectToDatabase(); PreparedStatement stmt = veza.prepareStatement("SELECT * FROM KORISNIK WHERE korisnicko_ime = ?")) {
            stmt.setString(1, korisnik);
            ResultSet rs = stmt.executeQuery();

            String ime = "";
            String prezime = "";
            String jmbag = "";
            String razinaOvlasti = "";
            LocalDate datumRodjenja = null;

            if (rs.next()) {
                ime = rs.getString("ime");
                prezime = rs.getString("prezime");
                jmbag = rs.getString("jmbag");
                datumRodjenja = rs.getDate("datum_rodjenja").toLocalDate();
            }

            setImePrezime(ime, prezime);
            setDatumRodjenja(datumRodjenja);
            setJmbag(jmbag);
            setRazinaOvlasti(datumRodjenja);
        } catch (SQLException sqlException) {
            logger.warn(sqlException.getMessage(), sqlException.getCause());
        } catch (DBPropertyException e) {
            logger.warn(e.getMessage(), e.getCause());
        }
    }

    public void setImePrezime(String ime, String prezime) {
        imePrezimeLabel.setText(ime + " " + prezime);
    }

    public void setDatumRodjenja(LocalDate datum) {
        datumRodjenjaLabel.setText(String.valueOf(datum));
    }

    public void setJmbag(String jmbag) {
        jmbagLabel.setText(jmbag);
    }

    public void setRazinaOvlasti(LocalDate datum) {
        Period period = Period.between(datum, LocalDate.now());
        int brojGodina = period.getYears();
        if (brojGodina < 14) razinaOvlastiLabel.setText("Osnovnoškolac");
        else if (brojGodina < 18) razinaOvlastiLabel.setText("Srednjoškolac");
        else razinaOvlastiLabel.setText("Akademik");
    }
}
