package kontroleri;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

public class OpisKnjigeUserController {
    private final ToggleGroup ocjene = new ToggleGroup();
    private String putanja;
    @FXML
    private RadioButton ocjena1, ocjena2, ocjena3, ocjena4, ocjena5;
    @FXML
    private Button preuzmiButton;
    @FXML
    private Button preuzmiIOtvoriButton;
    @FXML
    private Label nazivLabel;
    @FXML
    private Label autorLabel;
    @FXML
    private Label godinaIzdanjaLabel;
    @FXML
    private Label zemljaPorijeklaLabel;
    @FXML
    private Label izdavacLabel;
    @FXML
    private Label tipDjelaLabel;
    @FXML
    private Label prosjecnaOcjenaLabel;
    @FXML
    private Label objaviteljLabel;

    @FXML
    private void initialize() {
        OpisKnjigeModController.grupiraj(ocjena1, ocjene, ocjena2, ocjena3, ocjena4, ocjena5, prosjecnaOcjenaLabel, preuzmiButton, putanja, preuzmiIOtvoriButton);
    }

    public void postaviNaziv(String naziv) {
        nazivLabel.setText(naziv);
    }

    public void postaviAutora(String ime, String prezime) {
        autorLabel.setText(ime + " " + prezime);
    }

    public void postaviGodinuIzdanja(String godinaIzdanja) {
        godinaIzdanjaLabel.setText(godinaIzdanja);
    }

    public void postaviZemljuPorijekla(String zemljaPorijekla) {
        zemljaPorijeklaLabel.setText(zemljaPorijekla);
    }

    public void postaviIzdavaca(String izdavac) {
        izdavacLabel.setText(izdavac);
    }

    public void postaviTipDjela(String tipDjela) {
        tipDjelaLabel.setText(tipDjela);
    }

    public void postaviObjavitelja(String objavitelj) {
        objaviteljLabel.setText(objavitelj);
    }

    public void postaviProsjecnuOcjenu(String prosjecnaOcjena) {
        prosjecnaOcjenaLabel.setText(prosjecnaOcjena);
    }

    public void setPutanja(String putanja) {
        this.putanja = putanja;
    }
}