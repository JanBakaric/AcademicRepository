package kontroleri;

import baza.BazaPodataka;
import dodatno.AppendableObjectOutputStream;
import dodatno.Preuzimanje;
import dodatno.TipKnjige;
import entiteti.IzmjenaKnjige;
import entiteti.Knjiga;
import iznimke.QueryException;
import iznimke.SerijalizacijaException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

import static glavna.AkademskiRepozitorij.logger;

public class OvjeraKnjigeController extends Preuzimanje {
    private final Object lock = new Object();
    public static Knjiga knjigaZaOvjeru;
    Path izmjene = Paths.get("src/main/resources/dat/izmjeneNadKnjigama.dat");
    Stage stage = OvjeraKnjigaController.getStage();
    @FXML
    Label imePrezimeLabel, nazivLabel, godinaIzdanjaLabel, zemljaPorijeklaLabel, izdavacLabel;
    @FXML
    Button odobriButton;
    @FXML
    Button odbijButton;
    ToggleGroup tipKnjige = new ToggleGroup();
    @FXML
    RadioButton lektira;
    @FXML
    RadioButton udzbenik;
    @FXML
    RadioButton znanstveniRad;
    private String putanja;
    private String mjenjac;
    @FXML
    private Button preuzmiButton;
    @FXML
    private Button preuzmiIOtvoriButton;

    @FXML
    private void initialize() {
        lektira.setToggleGroup(tipKnjige);
        udzbenik.setToggleGroup(tipKnjige);
        znanstveniRad.setToggleGroup(tipKnjige);

        odobriButton.setDisable(true);

        lektira.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            odobriButton.setDisable(!noviOdabir);
        });
        udzbenik.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            odobriButton.setDisable(!noviOdabir);
        });
        znanstveniRad.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            odobriButton.setDisable(!noviOdabir);
        });

        OpisKnjigeModController.preuzimanje(preuzmiButton, putanja, preuzmiIOtvoriButton);
    }

    public void unesiNazivKnjige(String naziv) {
        nazivLabel.setText(naziv);
    }

    public void unesiImeIPrezimeAutora(String ime, String prezime) {
        imePrezimeLabel.setText(ime + " " + prezime);
    }

    public void unesiZemljuPorijekla(String drzava) {
        zemljaPorijeklaLabel.setText(drzava);
    }

    public void unesiGodinuIzdanja(String godina) {
        godinaIzdanjaLabel.setText(godina);
    }

    public void unesiIzdavaca(String email) {
        izdavacLabel.setText(email);
    }

    public synchronized void odobri() {
        ButtonType yesButton = new ButtonType("Da");
        ButtonType noButton = new ButtonType("Ne");

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Spremanje knjige");
        alert.setHeaderText("Jeste li sigurni?");
        alert.setContentText("Želite li dodati knjigu " + knjigaZaOvjeru.getNaziv() + "?");
        alert.getButtonTypes().setAll(yesButton, noButton);
        alert.showAndWait().ifPresent(buttonType -> {
            if (buttonType == yesButton) {
                synchronized (lock) {
                    try (Connection veza = BazaPodataka.connectToDatabase()) {
                        veza.setAutoCommit(false);
                        String novaPutanja = "";
                        if (knjigaZaOvjeru.getPutanja().endsWith(".txt"))
                            novaPutanja = "datoteke/trajne/" + knjigaZaOvjeru.getNaziv() + ".txt";
                        if (knjigaZaOvjeru.getPutanja().endsWith(".pdf"))
                            novaPutanja = "datoteke/trajne/" + knjigaZaOvjeru.getNaziv() + ".pdf";
                        if (knjigaZaOvjeru.getPutanja().endsWith(".docx"))
                            novaPutanja = "datoteke/trajne/" + knjigaZaOvjeru.getNaziv() + ".docx";

                        int i = 0;

                        PreparedStatement stmt;
                        stmt = veza.prepareStatement("DELETE FROM KNJIGE_ZA_OVJERU WHERE id = ?");
                        stmt.setInt(1, knjigaZaOvjeru.getId());

                        PreparedStatement stmt1;
                        stmt1 = veza.prepareStatement("INSERT INTO KNJIGA (naziv, ime_autora, prezime_autora, godina_izdanja, zemlja_porijekla, izdavac, putanja, tip_knjige, objavitelj) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        stmt1.setString(1, knjigaZaOvjeru.getNaziv());
                        stmt1.setString(2, knjigaZaOvjeru.getImeAutora());
                        stmt1.setString(3, knjigaZaOvjeru.getPrezimeAutora());
                        stmt1.setString(4, knjigaZaOvjeru.getGodinaIzdanja());
                        stmt1.setString(5, knjigaZaOvjeru.getZemljaPorijekla());
                        stmt1.setString(6, knjigaZaOvjeru.getIzdavac());
                        stmt1.setString(7, novaPutanja);

                        if (tipKnjige.getSelectedToggle() != null) {
                            switch (((RadioButton) tipKnjige.getSelectedToggle()).getText()) {
                                case "Lektira" -> {
                                    stmt1.setInt(8, 1);
                                    i = 1;
                                }
                                case "Udžbenik" -> {
                                    stmt1.setInt(8, 2);
                                    i = 2;
                                }
                                case "Zn. rad" -> {
                                    stmt1.setInt(8, 3);
                                    i = 3;
                                }
                            }
                        }
                        stmt1.setString(9, knjigaZaOvjeru.getObjavitelj());
                        stmt.executeUpdate();
                        stmt1.executeUpdate();

                        veza.commit();
                        veza.setAutoCommit(true);

                        try (FileOutputStream fw = new FileOutputStream(izmjene.toString(), true); AppendableObjectOutputStream out = new AppendableObjectOutputStream(fw)) {
                            IzmjenaKnjige izmjena = new IzmjenaKnjige();
                            izmjena.setNaziv(knjigaZaOvjeru.getNaziv());
                            izmjena.setImeAutora(knjigaZaOvjeru.getImeAutora());
                            izmjena.setPrezimeAutora(knjigaZaOvjeru.getPrezimeAutora());
                            izmjena.setGodinaIzdanja(knjigaZaOvjeru.getGodinaIzdanja());
                            izmjena.setZemljaPorijekla(knjigaZaOvjeru.getZemljaPorijekla());
                            izmjena.setIzdavac(knjigaZaOvjeru.getIzdavac());
                            switch (i) {
                                case 1 -> izmjena.setTipKnjige(TipKnjige.LEKTIRA);
                                case 2 -> izmjena.setTipKnjige(TipKnjige.UDZBENIK);
                                case 3 -> izmjena.setTipKnjige(TipKnjige.ZNANSTVENIRAD);
                                default -> izmjena.setTipKnjige(TipKnjige.NEODREDJENO);
                            }
                            izmjena.setPutanja(knjigaZaOvjeru.getPutanja());
                            izmjena.setObjavitelj(knjigaZaOvjeru.getObjavitelj());
                            izmjena.setVrijemeIzmjene(LocalDateTime.now());
                            izmjena.setMjenjac(mjenjac);

                            out.writeObject(izmjena);
                        } catch (IOException ioException) {
                            throw new SerijalizacijaException(ioException.getMessage(), ioException.getCause());
                        }

                        Alert info = new Alert(Alert.AlertType.INFORMATION);
                        info.setTitle("Spremanje knjige");
                        info.setHeaderText("Uspješno dodana knjiga");
                        info.setContentText("Dodana knjiga " + knjigaZaOvjeru.getNaziv());
                        info.show();

                        Files.copy(Path.of(knjigaZaOvjeru.getPutanja()), Path.of(novaPutanja), StandardCopyOption.REPLACE_EXISTING);
                        Files.deleteIfExists(Path.of(knjigaZaOvjeru.getPutanja()));
                        stage.close();
                    } catch (SQLException sqlException) {
                        try {
                            throw new QueryException(sqlException.getMessage(), sqlException.getCause());
                        } catch (QueryException e) {
                            logger.warn(e.getMessage(), e.getCause());
                        }
                    } catch (IOException ioException) {
                        logger.warn(ioException.getMessage(), ioException.getCause());
                    }
                }
            }
        });
    }

    public synchronized void odbij() throws QueryException {
        PreparedStatement stmt;
        try (Connection veza = BazaPodataka.connectToDatabase()) {
            if (veza != null) {
                stmt = veza.prepareStatement("DELETE FROM KNJIGE_ZA_OVJERU WHERE id = ?");
                stmt.setInt(1, knjigaZaOvjeru.getId());
                stmt.executeUpdate();
            }

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Spremanje knjige");
            alert.setHeaderText("Odbaćena knjiga");
            alert.setContentText("Odbaćen knjiga " + knjigaZaOvjeru.getNaziv());
            alert.show();

            Files.deleteIfExists(Path.of(knjigaZaOvjeru.getPutanja()));
            stage.close();
        } catch (SQLException sqlException) {
            throw new QueryException(sqlException.getMessage(), sqlException.getCause());
        } catch (IOException ioException) {
            logger.warn(ioException.getMessage(), ioException.getCause());
        }
    }

    public void setUsername(String username) {
        this.mjenjac = username;
    }

    public void setPutanja(String putanja) {
        this.putanja = putanja;
    }
}