package kontroleri;

import baza.BazaPodataka;
import entiteti.Knjiga;
import iznimke.DBPropertyException;
import iznimke.FXMLLoaderException;
import iznimke.SpajanjeNaBazuException;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Duration;
import sucelja.PotragaKnjigaSucelje;

import static glavna.AkademskiRepozitorij.logger;

public final class PotragaKnjigaUserController implements PotragaKnjigaSucelje {
    @FXML
    private Button objaviKnjiguButton;
    @FXML
    private Button pogledajKnjiguButton;
    @FXML
    private TableView<Knjiga> knjigaTableView;
    @FXML
    private TableColumn<Knjiga, String> nazivTableColumn;
    @FXML
    private TableColumn<Knjiga, String> imeAutoraTableColumn;
    @FXML
    private TableColumn<Knjiga, String> prezimeAutoraTableColumn;
    @FXML
    private TableColumn<Knjiga, String> tipTableColumn;
    @FXML
    private TextField pretragaTextField;
    @FXML
    private TextField drzavaPorijeklaTextField;
    @FXML
    private TextField godinaIzdanjaTextField;
    @FXML
    private TextField izdavacTextField;
    @FXML
    private CheckBox drzavaPorijeklaCheckbox;
    @FXML
    private CheckBox godinaIzdanjaCheckbox;
    @FXML
    private CheckBox izdavacCheckbox;
    @FXML
    private Label usernameLabel;

    @FXML
    void initialize() throws SpajanjeNaBazuException, DBPropertyException {
        drzavaPorijeklaTextField.setDisable(true);
        godinaIzdanjaTextField.setDisable(true);
        izdavacTextField.setDisable(true);
        pogledajKnjiguButton.setDisable(true);

        drzavaPorijeklaCheckbox.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            drzavaPorijeklaTextField.setDisable(!noviOdabir);
        });
        godinaIzdanjaCheckbox.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            godinaIzdanjaTextField.setDisable(!noviOdabir);
        });
        izdavacCheckbox.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            izdavacTextField.setDisable(!noviOdabir);
        });
        objaviKnjiguButton.setOnAction(e -> {
            try {
                showObjavaKnjigeScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });

        ObservableList<Knjiga> knjige = FXCollections.observableList(BazaPodataka.dohvatiKnjige());
        FilteredList<Knjiga> filteredList = new FilteredList<>(knjige);

        knjigaTableView.setItems(knjige);
        nazivTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNaziv()));
        imeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getImeAutora()));
        prezimeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrezimeAutora()));
        tipTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTipKnjige().toString()));

        knjigaTableView.getSelectionModel().selectedItemProperty().addListener((obs, stariOdabir, noviOdabir) -> {
            pogledajKnjiguButton.setDisable(noviOdabir == null);
        });

        pogledajKnjiguButton.setOnAction(e -> {
            Knjiga knjiga = knjigaTableView.getSelectionModel().getSelectedItem();
            if (knjiga != null) {
                try {
                    showOpisKnjigeKorisnikScreen(knjiga);
                } catch (FXMLLoaderException ex) {
                    logger.warn(ex.getMessage(), ex.getCause());
                }
            }
        });

        pretragaTextField.setOnKeyTyped(e -> pretrazi(filteredList));
        drzavaPorijeklaTextField.setOnKeyTyped(e -> pretrazi(filteredList));
        godinaIzdanjaTextField.setOnKeyTyped(e -> pretrazi(filteredList));
        izdavacTextField.setOnKeyTyped(e -> pretrazi(filteredList));

        Timeline osvjeziTimeline = new Timeline(new KeyFrame(Duration.seconds(10), e -> {
            knjige.clear();
            try {
                knjige.addAll(BazaPodataka.dohvatiKnjige());
            } catch (SpajanjeNaBazuException | DBPropertyException ex) {
                logger.error(ex.getMessage(), ex.getCause());
            }
            knjigaTableView.setItems(knjige);
        }));
        osvjeziTimeline.setCycleCount(Timeline.INDEFINITE);
        osvjeziTimeline.play();
    }

    public void pretrazi(FilteredList<Knjiga> filteredList) {
        PotragaKnjigaModController.pretrazivanje(filteredList, pretragaTextField, drzavaPorijeklaTextField, godinaIzdanjaTextField, izdavacTextField, drzavaPorijeklaCheckbox, knjigaTableView);
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }
}