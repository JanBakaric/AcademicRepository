package kontroleri;

import baza.BazaPodataka;
import entiteti.Knjiga;
import glavna.AkademskiRepozitorij;
import iznimke.DBPropertyException;
import iznimke.FXMLLoaderException;
import iznimke.SpajanjeNaBazuException;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public class OvjeraKnjigaController {
    public static String mjenjac;
    static Stage ovjeraOpisaKnjigeStage = new Stage();
    @FXML
    Label usernameLabel;
    Knjiga knjiga;
    @FXML
    private Button pogledajKnjiguButton;
    @FXML
    private TableView<Knjiga> knjigaTableView;
    @FXML
    private TableColumn<Knjiga, String> nazivKnjigeTableColumn;
    @FXML
    private TableColumn<Knjiga, String> imeAutoraTableColumn;
    @FXML
    private TableColumn<Knjiga, String> prezimeAutoraTableColumn;

    public static Stage getStage() {
        return ovjeraOpisaKnjigeStage;
    }

    @FXML
    void initialize() throws SpajanjeNaBazuException, DBPropertyException {
        ObservableList<Knjiga> knjige = FXCollections.observableList(BazaPodataka.dohvatiKnjigeZaOvjeru());

        knjigaTableView.setItems(knjige);
        nazivKnjigeTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNaziv()));
        imeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getImeAutora()));
        prezimeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrezimeAutora()));

        knjigaTableView.getSelectionModel().selectedItemProperty().addListener((observableValue, stariOdabir, noviOdabir) -> {
            knjiga = noviOdabir;
        });

        Timeline osvjeziTimeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            knjige.clear();
            try {
                knjige.addAll(BazaPodataka.dohvatiKnjigeZaOvjeru());
            } catch (SpajanjeNaBazuException | DBPropertyException ex) {
                logger.error(ex.getMessage(), ex.getCause());
            }
            knjigaTableView.setItems(knjige);
        }));
        osvjeziTimeline.setCycleCount(Timeline.INDEFINITE);
        osvjeziTimeline.play();
    }

    public void showOvjeraKnjigeScreen() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("ovjeraKnjige.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            if (knjiga != null) {
                OvjeraKnjigeController ovjeraKnjigeController = fxmlLoader.getController();
                ovjeraKnjigeController.unesiNazivKnjige(knjiga.getNaziv());
                ovjeraKnjigeController.unesiImeIPrezimeAutora(knjiga.getImeAutora(), knjiga.getPrezimeAutora());
                ovjeraKnjigeController.unesiZemljuPorijekla(!knjiga.getZemljaPorijekla().equals("") ? knjiga.getZemljaPorijekla() : "Nepoznata zemlja porijekla");
                ovjeraKnjigeController.unesiGodinuIzdanja(!knjiga.getGodinaIzdanja().equals("") ? knjiga.getGodinaIzdanja() : "Nepoznata godina izdanja");
                ovjeraKnjigeController.unesiIzdavaca(!knjiga.getIzdavac().equals("") ? knjiga.getIzdavac() : "Nepoznat izdavač");
                ovjeraKnjigeController.setPutanja(knjiga.getPutanja());

                OvjeraKnjigeController.knjigaZaOvjeru = knjiga;
                ovjeraKnjigeController.setUsername(usernameLabel.getText());

                ovjeraOpisaKnjigeStage.setTitle("Ovjeravanje korisnika");
                ovjeraOpisaKnjigeStage.setScene(scene);
                ovjeraOpisaKnjigeStage.setResizable(false);
                ovjeraOpisaKnjigeStage.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Neoznačena knjiga");
                alert.setHeaderText("Neoznačena knjiga");
                alert.setContentText("Odaberite knjigu iz tablice prije nego što nastavite!");
                alert.show();
            }
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }
}