package kontroleri;

import baza.BazaPodataka;
import entiteti.IzmjenaKnjige;
import entiteti.Knjiga;
import iznimke.DBPropertyException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

import static glavna.AkademskiRepozitorij.logger;

public class IzmijeniController {
    public static Knjiga knjigaZaIzmjenu;
    private final Object lock = new Object();
    Path izmjene = Path.of("src/main/resources/dat/izmjeneNadKnjigama.dat");
    @FXML
    private Button izmijeniButton;
    @FXML
    private TextField nazivTextField;
    @FXML
    private TextField imeTextField;
    @FXML
    private TextField prezimeTextField;
    @FXML
    private TextField godinaIzdanjaTextField;
    @FXML
    private TextField zemljaPorijeklaTextField;
    @FXML
    private TextField izdavacTextField;
    @FXML
    private Label usernameLabel;

    public void izmijeniKnjigu() {
        ButtonType yesButton = new ButtonType("Da");
        ButtonType noButton = new ButtonType("Ne");

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Ažuriranje knjige");
        alert.setHeaderText("Jeste li sigurni da želite ažurirati knjigu s repozitorija?");
        alert.getButtonTypes().setAll(yesButton, noButton);
        alert.showAndWait().ifPresent(buttonType -> {
            if (buttonType == yesButton) {
                synchronized (lock) {
                    try (Connection veza = BazaPodataka.connectToDatabase(); PreparedStatement stmt = veza.prepareStatement("UPDATE KNJIGA SET naziv = ?, ime_autora = ?, prezime_autora = ?, godina_izdanja = ?, zemlja_porijekla = ?, izdavac = ? WHERE ID = ?")) {
                        String naziv = nazivTextField.getText();
                        String ime = imeTextField.getText();
                        String prezime = prezimeTextField.getText();
                        String godinaIzdanja = godinaIzdanjaTextField.getText();
                        String zemljaPorijekla = zemljaPorijeklaTextField.getText();
                        String izdavac = izdavacTextField.getText();

                        stmt.setString(1, naziv);
                        stmt.setString(2, ime);
                        stmt.setString(3, prezime);
                        stmt.setString(4, godinaIzdanja);
                        stmt.setString(5, zemljaPorijekla);
                        stmt.setString(6, izdavac);
                        stmt.setInt(7, knjigaZaIzmjenu.getId());
                        stmt.executeUpdate();

                        IzmjenaKnjige izmjena = new IzmjenaKnjige();
                        izmjena.setStariNaziv(knjigaZaIzmjenu.getNaziv());
                        izmjena.setNaziv(naziv);
                        izmjena.setStaroImeAutora(knjigaZaIzmjenu.getImeAutora());
                        izmjena.setImeAutora(ime);
                        izmjena.setStaroPrezimeAutora(knjigaZaIzmjenu.getPrezimeAutora());
                        izmjena.setPrezimeAutora(prezime);
                        izmjena.setStaraGodinaIzdanja(knjigaZaIzmjenu.getGodinaIzdanja());
                        izmjena.setGodinaIzdanja(godinaIzdanja);
                        izmjena.setStaraZemljaPorijekla(knjigaZaIzmjenu.getZemljaPorijekla());
                        izmjena.setZemljaPorijekla(zemljaPorijekla);
                        izmjena.setStariIzdavac(knjigaZaIzmjenu.getIzdavac());
                        izmjena.setIzdavac(izdavac);
                        izmjena.setTipKnjige(knjigaZaIzmjenu.getTipKnjige());
                        izmjena.setPutanja(knjigaZaIzmjenu.getPutanja());
                        izmjena.setObjavitelj(knjigaZaIzmjenu.getObjavitelj());
                        izmjena.setVrijemeIzmjene(LocalDateTime.now());
                        izmjena.setMjenjac(usernameLabel.getText());

                        OpisKnjigeModController.serijalizacijaIzmjene(izmjena, izmjene);

                        Stage stage = (Stage) nazivTextField.getScene().getWindow();
                        stage.close();
                    } catch (SQLException sqlException) {
                        logger.warn(sqlException.getMessage(), sqlException.getCause());
                    } catch (DBPropertyException e) {
                        logger.warn(e.getMessage(), e.getCause());
                    }
                }
                }
        });
    }

    public void postaviUsername(String username) {
        usernameLabel.setText(username);
    }
}
