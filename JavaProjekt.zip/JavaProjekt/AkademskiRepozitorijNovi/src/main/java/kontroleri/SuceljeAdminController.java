package kontroleri;

import dodatno.FXMLLoaderSpajanje;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import sucelja.GlavnoSucelje;

import static glavna.AkademskiRepozitorij.logger;

public non-sealed class SuceljeAdminController implements GlavnoSucelje {
    Stage ovjeraIzmjenaStage = new Stage();
    @FXML
    private Button potraziKnjiguButton;
    @FXML
    private Button objaviKnjiguButton;
    @FXML
    private Button odjaviMeButton;
    @FXML
    private Button ovjeraButton;
    @FXML
    private Label imeLabel;
    @FXML
    private Label prezimeLabel;
    @FXML
    private Label razinaOvlastiLabel;
    @FXML
    private Label usernameLabel;

    @FXML
    void initialize() {
        potraziKnjiguButton.setOnAction(e -> {
            try {
                showPotragaKnjigaDjelatnikScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        objaviKnjiguButton.setOnAction(e -> {
            try {
                showObjavaKnjigeScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        odjaviMeButton.setOnAction(e -> {
            try {
                showKorisnickaPrijavaScreen();
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        ovjeraButton.setOnAction(e -> {
            try {
                showOvjeraScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
    }

    public void postaviIme(String ime) {
        imeLabel.setText(ime);
    }

    public void postaviPrezime(String prezime) {
        prezimeLabel.setText(prezime);
    }

    public void postaviRolu(String rola) {
        razinaOvlastiLabel.setText(rola);
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }

    public void showIzmjeneScreen() throws FXMLLoaderException {
        FXMLLoaderSpajanje.spoji("izmjene.fxml", "Odabir izmjene", ovjeraIzmjenaStage);
    }
}