package kontroleri;

import dodatno.FXMLLoaderSpajanje;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class IzmjeneController {
    @FXML
    Button ovjeraKnjigaButton, ovjeraKorisnikaButton;

    public void showOvjeraIzmjenaKnjigaScreen() throws FXMLLoaderException {
        Stage stage = (Stage) ovjeraKnjigaButton.getScene().getWindow();
        FXMLLoaderSpajanje.spoji("ovjeraIzmjenaKnjiga.fxml", "Izmjene knjiga", stage);
        stage.setAlwaysOnTop(false);
    }

    public void showOvjeraIzmjenaKorisnikaScreen() throws FXMLLoaderException {
        Stage stage = (Stage) ovjeraKorisnikaButton.getScene().getWindow();
        FXMLLoaderSpajanje.spoji("ovjeraIzmjenaKorisnika.fxml", "Izmjene korisnika", stage);
        stage.setAlwaysOnTop(false);
    }
}
