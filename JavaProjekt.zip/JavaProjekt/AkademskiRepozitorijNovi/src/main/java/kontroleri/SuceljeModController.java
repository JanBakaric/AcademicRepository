package kontroleri;

import glavna.AkademskiRepozitorij;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import sucelja.GlavnoSucelje;

import java.io.IOException;

import static glavna.AkademskiRepozitorij.logger;

public non-sealed class SuceljeModController implements GlavnoSucelje {
    Stage ovjeraKnjigaStage = new Stage();
    @FXML
    private Button potraziKnjiguButton;
    @FXML
    private Button objaviKnjiguButton;
    @FXML
    private Button odjaviMeButton;
    @FXML
    private Label imeLabel;
    @FXML
    private Label prezimeLabel;
    @FXML
    private Label razinaOvlastiLabel;
    @FXML
    private Label usernameLabel;

    @FXML
    void initialize() {
        potraziKnjiguButton.setOnAction(e -> {
            try {
                showPotragaKnjigaDjelatnikScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        objaviKnjiguButton.setOnAction(e -> {
            try {
                showObjavaKnjigeScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
        odjaviMeButton.setOnAction(e -> {
            try {
                showKorisnickaPrijavaScreen();
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });
    }

    public void postaviIme(String ime) {
        imeLabel.setText(ime);
    }

    public void postaviPrezime(String prezime) {
        prezimeLabel.setText(prezime);
    }

    public void postaviRolu(String rola) {
        razinaOvlastiLabel.setText(rola);
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }

    public void showOvjeraKnjigaScreen() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("ovjeraKnjiga.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            ovjeraKnjigaStage.setTitle("Ovjera knjiga");
            ovjeraKnjigaStage.setResizable(false);
            OvjeraKnjigaController ovjeraKnjigaController = fxmlLoader.getController();
            ovjeraKnjigaController.postaviUsername(usernameLabel.getText());
            ovjeraKnjigaStage.setScene(scene);
            ovjeraKnjigaStage.show();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }
}
