package kontroleri;

import dodatno.AppendableObjectInputStream;
import entiteti.IzmjenaKorisnika;
import iznimke.DeserijalizacijaException;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Duration;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static glavna.AkademskiRepozitorij.logger;

public class OvjeraIzmjenaKorisnikaController {
    private final Object lock = new Object();
    @FXML
    TableView<IzmjenaKorisnika> korisnikTableView;
    @FXML
    TableColumn<IzmjenaKorisnika, String> imeKorisnikaTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> prezimeKorisnikaTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> jmbagKorisnikaTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> emailKorisnikaTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> datumRodjenjaKorisnikaTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> korisnickoImeKorisnikaTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> djelatnikTableColumn;
    @FXML
    TableColumn<IzmjenaKorisnika, String> vrijemeDodatkaKorisnikaTableColumn;

    @FXML
    void initialize() throws DeserijalizacijaException {
        ObservableList<IzmjenaKorisnika> izmjeneDat = FXCollections.observableList(dohvatiIzmjene());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

        korisnikTableView.setItems(izmjeneDat);
        imeKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getIme()));
        prezimeKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrezime()));
        jmbagKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getJmbag()));
        emailKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEmail()));
        datumRodjenjaKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getDatumRodjenja().toString()));
        korisnickoImeKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getKorisnickoIme()));
        djelatnikTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMjenjac()));
        vrijemeDodatkaKorisnikaTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getVrijemeIzmjene().format(formatter)));

        Timeline osvjeziTimeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            izmjeneDat.clear();
            try {
                izmjeneDat.addAll(dohvatiIzmjene());
            } catch (DeserijalizacijaException ex) {
                logger.error(ex.getMessage(), ex.getCause());
            }
            korisnikTableView.setItems(izmjeneDat);
        }));
        osvjeziTimeline.setCycleCount(Timeline.INDEFINITE);
        osvjeziTimeline.play();
    }

    public ArrayList<IzmjenaKorisnika> dohvatiIzmjene() throws DeserijalizacijaException {
        ArrayList<IzmjenaKorisnika> izmjene = new ArrayList<>();

        synchronized (lock) {
            try (FileInputStream fin = new FileInputStream("src/main/resources/dat/izmjeneNadKorisnicima.dat"); AppendableObjectInputStream oin = new AppendableObjectInputStream(fin)) {
                while (true) {
                    try {
                        IzmjenaKorisnika izmjena = (IzmjenaKorisnika) oin.readObject();
                        izmjene.add(izmjena);
                    } catch (EOFException eofException) {
                        logger.info("Deserijalizirane izmjene!");
                        break;
                    }
                }
            } catch (IOException ioException) {
                throw new DeserijalizacijaException(ioException.getMessage(), ioException.getCause());
            } catch (ClassNotFoundException e) {
                logger.warn(e.getMessage(), e.getCause());
            }
        }

        return izmjene;
    }
}
