package kontroleri;

import baza.BazaPodataka;
import entiteti.Knjiga;
import iznimke.DBPropertyException;
import iznimke.FXMLLoaderException;
import iznimke.SpajanjeNaBazuException;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import sucelja.PotragaKnjigaSucelje;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static glavna.AkademskiRepozitorij.logger;

public final class PotragaKnjigaModController implements PotragaKnjigaSucelje, Initializable {
    private ScheduledExecutorService osvjezivac;
    ObservableList<Knjiga> knjige;
    @FXML
    private Button objaviKnjiguButton;
    @FXML
    private Button pogledajKnjiguButton;
    @FXML
    private TableView<Knjiga> knjigaTableView;
    @FXML
    private TableColumn<Knjiga, String> nazivTableColumn;
    @FXML
    private TableColumn<Knjiga, String> imeAutoraTableColumn;
    @FXML
    private TableColumn<Knjiga, String> prezimeAutoraTableColumn;
    @FXML
    private TableColumn<Knjiga, String> tipTableColumn;
    @FXML
    private TextField pretragaTextField;
    @FXML
    private TextField drzavaPorijeklaTextField;
    @FXML
    private TextField godinaIzdanjaTextField;
    @FXML
    private TextField izdavacTextField;
    @FXML
    private CheckBox drzavaPorijeklaCheckbox;
    @FXML
    private CheckBox godinaIzdanjaCheckbox;
    @FXML
    private CheckBox izdavacCheckbox;
    @FXML
    private Label usernameLabel;

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        drzavaPorijeklaTextField.setDisable(true);
        godinaIzdanjaTextField.setDisable(true);
        izdavacTextField.setDisable(true);
        pogledajKnjiguButton.setDisable(true);

        drzavaPorijeklaCheckbox.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> drzavaPorijeklaTextField.setDisable(!noviOdabir));
        godinaIzdanjaCheckbox.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> godinaIzdanjaTextField.setDisable(!noviOdabir));
        izdavacCheckbox.selectedProperty().addListener((obs, stariOdabir, noviOdabir) -> izdavacTextField.setDisable(!noviOdabir));
        objaviKnjiguButton.setOnAction(e -> {
            try {
                showObjavaKnjigeScreen(usernameLabel.getText());
            } catch (FXMLLoaderException ex) {
                logger.warn(ex.getMessage(), ex.getCause());
            }
        });

        try {
            knjige = FXCollections.observableList(BazaPodataka.dohvatiKnjige());
        } catch (SpajanjeNaBazuException | DBPropertyException e) {
            logger.error(e.getMessage(), e.getCause());
        }
        FilteredList<Knjiga> filteredList = new FilteredList<>(knjige);

        knjigaTableView.setItems(knjige);
        nazivTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNaziv()));
        imeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getImeAutora()));
        prezimeAutoraTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrezimeAutora()));
        tipTableColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTipKnjige().toString()));

        knjigaTableView.getSelectionModel().selectedItemProperty().addListener((obs, stariOdabir, noviOdabir) -> pogledajKnjiguButton.setDisable(noviOdabir == null));

        pogledajKnjiguButton.setOnAction(e -> {
            Knjiga knjiga = knjigaTableView.getSelectionModel().getSelectedItem();
            if (knjiga != null) {
                try {
                    showOpisKnjigeDjelatnikScreen(knjiga, usernameLabel.getText());
                } catch (FXMLLoaderException ex) {
                    logger.warn(ex.getMessage(), ex.getCause());
                }
            }
        });

        pretragaTextField.setOnKeyTyped(e -> pretrazi(filteredList));
        drzavaPorijeklaTextField.setOnKeyTyped(e -> pretrazi(filteredList));
        godinaIzdanjaTextField.setOnKeyTyped(e -> pretrazi(filteredList));
        izdavacTextField.setOnKeyTyped(e -> pretrazi(filteredList));

        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdownScheduler));

        osvjezivac = Executors.newSingleThreadScheduledExecutor();
        osvjezivac.scheduleAtFixedRate(this::osvjeziPodatke, 0, 10, TimeUnit.SECONDS);
    }

    public void pretrazi(FilteredList<Knjiga> filteredList) {
        pretrazivanje(filteredList, pretragaTextField, drzavaPorijeklaTextField, godinaIzdanjaTextField, izdavacTextField, drzavaPorijeklaCheckbox, knjigaTableView);
    }

    public static void pretrazivanje(FilteredList<Knjiga> filteredList, TextField pretragaTextField, TextField drzavaPorijeklaTextField, TextField godinaIzdanjaTextField, TextField izdavacTextField, CheckBox drzavaPorijeklaCheckbox, TableView<Knjiga> knjigaTableView) {
        String pretraga = pretragaTextField.getText();
        String drzavaPorijekla = drzavaPorijeklaTextField.getText();
        String godinaIzdanja = godinaIzdanjaTextField.getText();
        String izdavac = izdavacTextField.getText();

        filteredList.setPredicate(knjiga -> {
            String naziv = knjiga.getNaziv().toLowerCase();
            String autor = knjiga.getImeAutora().concat(" " + knjiga.getPrezimeAutora()).toLowerCase();
            boolean uspjeh = naziv.contains(pretraga.toLowerCase()) || autor.contains(pretraga.toLowerCase());
            if (!drzavaPorijekla.isEmpty() && drzavaPorijeklaCheckbox.selectedProperty().get()) {
                String zemljaPorijekla = knjiga.getZemljaPorijekla().toLowerCase();
                uspjeh = uspjeh && zemljaPorijekla.contains(drzavaPorijekla.toLowerCase());
            }
            if (!godinaIzdanja.isEmpty() && drzavaPorijeklaCheckbox.selectedProperty().get()) {
                String godIzdanja = knjiga.getGodinaIzdanja().toLowerCase();
                uspjeh = uspjeh && godIzdanja.contains(godinaIzdanja.toLowerCase());
            }
            if (!izdavac.isEmpty() && drzavaPorijeklaCheckbox.selectedProperty().get()) {
                String biblioteka = knjiga.getIzdavac().toLowerCase();
                uspjeh = uspjeh && biblioteka.contains(izdavac.toLowerCase());
            }
            return uspjeh;
        });

        knjigaTableView.setItems(FXCollections.observableList(filteredList));
    }

    public void postaviUsername(String usernameVan) {
        usernameLabel.setText(usernameVan);
    }

    private void osvjeziPodatke() {
        ArrayList<Knjiga> noveKnjige = new ArrayList<>();
        try {
            noveKnjige.addAll(BazaPodataka.dohvatiKnjige());
        } catch (SpajanjeNaBazuException | DBPropertyException e) {
            logger.error(e.getMessage(), e.getCause());
        }
        Platform.runLater(() -> {
            knjige.clear();
            knjige.addAll(FXCollections.observableList(noveKnjige));
        });
    }

    public void shutdownScheduler() {
        if (osvjezivac != null && !osvjezivac.isShutdown()) {
            osvjezivac.shutdown();
        }
    }
}
