package kontroleri;

import glavna.AkademskiRepozitorij;
import iznimke.FXMLLoaderException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class OvjeraController {
    public static String mjenjac;
    Stage ovjeraKnjigaStage = new Stage();
    Stage ovjeraKorisnikaStage = new Stage();
    @FXML
    Button ovjeraKnjigaButton, ovjeraKorisnikaButton;

    public void showOvjeraKnjigaScreen() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("ovjeraKnjiga.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            ovjeraKnjigaStage.setTitle("Ovjera knjiga");
            ovjeraKnjigaStage.setResizable(false);
            OvjeraKnjigaController ovjeraKnjigaController = fxmlLoader.getController();
            ovjeraKnjigaController.postaviUsername(mjenjac);
            ovjeraKnjigaStage.setScene(scene);
            ovjeraKnjigaStage.show();
            Stage ovaj = (Stage) ovjeraKnjigaButton.getScene().getWindow();
            ovaj.close();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }

    public void showOvjeraKorisnikaScreen() throws FXMLLoaderException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(AkademskiRepozitorij.class.getResource("ovjeraKorisnika.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            ovjeraKorisnikaStage.setTitle("Ovjera korisnika");
            ovjeraKorisnikaStage.setResizable(false);
            OvjeraKorisnikaController ovjeraKorisnikaController = fxmlLoader.getController();
            ovjeraKorisnikaController.postaviUsername(mjenjac);
            ovjeraKorisnikaStage.setScene(scene);
            ovjeraKorisnikaStage.show();
            Stage ovaj = (Stage) ovjeraKnjigaButton.getScene().getWindow();
            ovaj.close();
        } catch (IOException ioException) {
            throw new FXMLLoaderException(ioException.getMessage(), ioException.getCause());
        }
    }
}