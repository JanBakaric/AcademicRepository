package kontroleri;

import baza.BazaPodataka;
import entiteti.Knjiga;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

import java.io.File;

public class ObjavaKnjigeController {
    @FXML
    private Button odaberiDatotekuButton;
    @FXML
    private Button objaviButton;
    @FXML
    private TextField nazivTextField;
    @FXML
    private TextField imeTextField;
    @FXML
    private TextField prezimeTextField;
    @FXML
    private TextField godinaIzdanjaTextField;
    @FXML
    private TextField zemljaPorijeklaTextField;
    @FXML
    private TextField izdavacTextField;
    @FXML
    private Label usernameLabel;

    @FXML
    void initialize() {
        odaberiDatotekuButton.setOnAction(e -> odaberiDatoteku());
        objaviButton.setOnAction(e -> objaviKnjigu());
    }

    public void odaberiDatoteku() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new ExtensionFilter("Tekstualne datoteke", "*.txt"));
        fileChooser.getExtensionFilters().add(new ExtensionFilter("MSWord datoteke", "*.docx"));
        fileChooser.getExtensionFilters().add(new ExtensionFilter("PDF datoteke", "*.pdf"));
        fileChooser.getExtensionFilters().add(new ExtensionFilter("Sve datoteke", "*.*"));
        File selectedFile = fileChooser.showOpenDialog(odaberiDatotekuButton.getScene().getWindow());

        if (selectedFile != null) {
            String filePath = selectedFile.getAbsolutePath();
            odaberiDatotekuButton.setText(filePath);
        }
    }

    public void objaviKnjigu() {
        String naziv = nazivTextField.getText();
        String ime = imeTextField.getText();
        String prezime = prezimeTextField.getText();
        String godinaIzdanja = godinaIzdanjaTextField.getText();
        String zemljaPorijekla = zemljaPorijeklaTextField.getText();
        String izdavac = izdavacTextField.getText();
        String putanja = odaberiDatotekuButton.getText();

        Knjiga.KnjigaBuilder knjigaB = new Knjiga.KnjigaBuilder(69, naziv, ime, prezime);

        knjigaB.setGodinaIzdanja(godinaIzdanja);
        knjigaB.setZemljaPorijekla(zemljaPorijekla);
        knjigaB.setIzdavac(izdavac);
        knjigaB.setPutanja(putanja);
        knjigaB.setObjavitelj(usernameLabel.getText());
        Knjiga knjiga = knjigaB.build();

        BazaPodataka.ovjerenjeKnjige(knjiga);
        Stage stage = (Stage) nazivTextField.getScene().getWindow();
        stage.close();
    }

    public void postaviUsername(String username) {
        usernameLabel.setText(username);
    }
}
