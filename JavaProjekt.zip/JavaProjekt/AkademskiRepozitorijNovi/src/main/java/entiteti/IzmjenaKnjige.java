package entiteti;

import dodatno.TipKnjige;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

public class IzmjenaKnjige implements Serializable {
    @Serial
    private static final long serialVersionUID = -3513375554250399441L;
    private String naziv = "";
    private String stariNaziv = "";
    private String imeAutora = "";
    private String staroImeAutora = "";
    private String prezimeAutora = "";
    private String staroPrezimeAutora = "";
    private String godinaIzdanja = "";
    private String staraGodinaIzdanja = "";
    private String zemljaPorijekla = "";
    private String staraZemljaPorijekla = "";
    private String izdavac = "";
    private String stariIzdavac = "";
    private TipKnjige tipKnjige;
    private String objavitelj = "";
    private String putanja;
    private String mjenjac;
    private LocalDateTime vrijemeIzmjene;

    public IzmjenaKnjige() {
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getStariNaziv() {
        return stariNaziv;
    }

    public void setStariNaziv(String stariNaziv) {
        this.stariNaziv = stariNaziv;
    }

    public String getImeAutora() {
        return imeAutora;
    }

    public void setImeAutora(String imeAutora) {
        this.imeAutora = imeAutora;
    }

    public String getStaroImeAutora() {
        return staroImeAutora;
    }

    public void setStaroImeAutora(String staroImeAutora) {
        this.staroImeAutora = staroImeAutora;
    }

    public String getPrezimeAutora() {
        return prezimeAutora;
    }

    public void setPrezimeAutora(String prezimeAutora) {
        this.prezimeAutora = prezimeAutora;
    }

    public String getStaroPrezimeAutora() {
        return staroPrezimeAutora;
    }

    public void setStaroPrezimeAutora(String staroPrezimeAutora) {
        this.staroPrezimeAutora = staroPrezimeAutora;
    }

    public String getGodinaIzdanja() {
        return godinaIzdanja;
    }

    public void setGodinaIzdanja(String godinaIzdanja) {
        this.godinaIzdanja = godinaIzdanja;
    }

    public String getStaraGodinaIzdanja() {
        return staraGodinaIzdanja;
    }

    public void setStaraGodinaIzdanja(String staraGodinaIzdanja) {
        this.staraGodinaIzdanja = staraGodinaIzdanja;
    }

    public String getZemljaPorijekla() {
        return zemljaPorijekla;
    }

    public void setZemljaPorijekla(String zemljaPorijekla) {
        this.zemljaPorijekla = zemljaPorijekla;
    }

    public String getStaraZemljaPorijekla() {
        return staraZemljaPorijekla;
    }

    public void setStaraZemljaPorijekla(String staraZemljaPorijekla) {
        this.staraZemljaPorijekla = staraZemljaPorijekla;
    }

    public String getIzdavac() {
        return izdavac;
    }

    public void setIzdavac(String izdavac) {
        this.izdavac = izdavac;
    }

    public String getStariIzdavac() {
        return stariIzdavac;
    }

    public void setStariIzdavac(String stariIzdavac) {
        this.stariIzdavac = stariIzdavac;
    }

    public TipKnjige getTipKnjige() {
        return tipKnjige;
    }

    public void setTipKnjige(TipKnjige tipKnjige) {
        this.tipKnjige = tipKnjige;
    }

    public String getPutanja() {
        return putanja;
    }

    public void setPutanja(String putanja) {
        this.putanja = putanja;
    }

    public String getObjavitelj() {
        return objavitelj;
    }

    public void setObjavitelj(String objavitelj) {
        this.objavitelj = objavitelj;
    }

    public String getMjenjac() {
        return mjenjac;
    }

    public void setMjenjac(String mjenjac) {
        this.mjenjac = mjenjac;
    }

    public LocalDateTime getVrijemeIzmjene() {
        return vrijemeIzmjene;
    }

    public void setVrijemeIzmjene(LocalDateTime vrijemeIzmjene) {
        this.vrijemeIzmjene = vrijemeIzmjene;
    }

}