package entiteti;

import dodatno.TipKnjige;

public class Knjiga {
    //obavezni parametri
    private final Integer id;
    private final String naziv;
    private final String imeAutora;
    private final String prezimeAutora;

    //neobavezni parametri
    private final String godinaIzdanja;
    private final String zemljaPorijekla;
    private final String izdavac;
    private final TipKnjige tipKnjige;
    private final String putanja;
    private final String objavitelj;

    private Knjiga(KnjigaBuilder builder) {
        this.id = builder.id;
        this.naziv = builder.naziv;
        this.imeAutora = builder.imeAutora;
        this.prezimeAutora = builder.prezimeAutora;
        this.godinaIzdanja = builder.godinaIzdanja;
        this.zemljaPorijekla = builder.zemljaPorijekla;
        this.izdavac = builder.izdavac;
        this.putanja = builder.putanja;
        this.tipKnjige = builder.tipKnjige;
        this.objavitelj = builder.objavitelj;
    }

    public Integer getId() {
        return id;
    }

    public String getNaziv() {
        return naziv;
    }

    public String getImeAutora() {
        return imeAutora;
    }

    public String getPrezimeAutora() {
        return prezimeAutora;
    }

    public String getGodinaIzdanja() {
        return godinaIzdanja;
    }

    public String getZemljaPorijekla() {
        return zemljaPorijekla;
    }

    public String getIzdavac() {
        return izdavac;
    }

    public TipKnjige getTipKnjige() {
        return tipKnjige;
    }

    public String getPutanja() {
        return putanja;
    }

    public String getObjavitelj() {
        return objavitelj;
    }

    public static class KnjigaBuilder {
        //obavezni parametri
        private final Integer id;
        private final String naziv;
        private final String imeAutora;
        private final String prezimeAutora;

        //neobavezni parametri
        private String godinaIzdanja;
        private String zemljaPorijekla;
        private String izdavac;
        private TipKnjige tipKnjige;
        private String putanja;
        private String objavitelj;

        public KnjigaBuilder(Integer id, String naziv, String imeAutora, String prezimeAutora) {
            this.id = id;
            this.naziv = naziv;
            this.imeAutora = imeAutora;
            this.prezimeAutora = prezimeAutora;
        }

        public KnjigaBuilder setGodinaIzdanja(String godinaIzdanja) {
            this.godinaIzdanja = godinaIzdanja;
            return this;
        }

        public KnjigaBuilder setZemljaPorijekla(String zemljaPorijekla) {
            this.zemljaPorijekla = zemljaPorijekla;
            return this;
        }

        public KnjigaBuilder setIzdavac(String izdavac) {
            this.izdavac = izdavac;
            return this;
        }

        public KnjigaBuilder setTipKnjige(Integer tip) {
            switch (tip) {
                case 1 -> this.tipKnjige = TipKnjige.LEKTIRA;
                case 2 -> this.tipKnjige = TipKnjige.UDZBENIK;
                case 3 -> this.tipKnjige = TipKnjige.ZNANSTVENIRAD;
                default -> this.tipKnjige = TipKnjige.NEODREDJENO;
            }
            return this;
        }

        public KnjigaBuilder setPutanja(String putanja) {
            this.putanja = putanja;
            return this;
        }

        public KnjigaBuilder setObjavitelj(String objavitelj) {
            this.objavitelj = objavitelj;
            return this;
        }

        public Knjiga build() {
            return new Knjiga(this);
        }
    }
}