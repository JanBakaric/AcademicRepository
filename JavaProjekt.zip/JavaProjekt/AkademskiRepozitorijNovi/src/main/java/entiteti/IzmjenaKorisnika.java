package entiteti;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class IzmjenaKorisnika implements Serializable {
    @Serial
    private static final long serialVersionUID = 2145157284316868393L;
    private final String ime;
    private final String prezime;
    private final String jmbag;
    private final String email;
    private final LocalDate datumRodjenja;
    private final String korisnickoIme;
    private final String mjenjac;
    private final LocalDateTime vrijemeIzmjene;

    public IzmjenaKorisnika(Gost korisnik, LocalDateTime vrijemeIzmjene, String mjenjac) {
        this.ime = korisnik.getIme();
        this.prezime = korisnik.getPrezime();
        this.jmbag = korisnik.getJmbag();
        this.email = korisnik.getEmail();
        this.datumRodjenja = korisnik.getDatumRodjenja();
        this.korisnickoIme = korisnik.getKorisnickoIme();
        this.vrijemeIzmjene = vrijemeIzmjene;
        this.mjenjac = mjenjac;
    }

    public String getIme() {
        return ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public String getJmbag() {
        return jmbag;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getDatumRodjenja() {
        return datumRodjenja;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public String getMjenjac() {
        return mjenjac;
    }

    public LocalDateTime getVrijemeIzmjene() {
        return vrijemeIzmjene;
    }
}