package entiteti;

import dodatno.OvlastDjelatnika;

import java.time.LocalDate;

public class Djelatnik extends Korisnik {
    private OvlastDjelatnika ovlastDjelatnika;

    public Djelatnik(Integer id, String ime, String prezime, String korisnickoIme, String lozinka, LocalDate datumRodjenja, String email, OvlastDjelatnika ovlastDjelatnika) {
        super(id, ime, prezime, korisnickoIme, lozinka, datumRodjenja, email);
        this.ovlastDjelatnika = ovlastDjelatnika;
    }

    public OvlastDjelatnika getOvlastDjelatnika() {
        return ovlastDjelatnika;
    }
}