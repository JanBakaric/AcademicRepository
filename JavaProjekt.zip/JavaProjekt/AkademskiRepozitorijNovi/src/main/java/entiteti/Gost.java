package entiteti;

import dodatno.OvlastGosta;

import java.time.LocalDate;

public class Gost extends Korisnik {
    private transient OvlastGosta ovlastGosta;
    private String jmbag;

    public Gost(Integer id, String ime, String prezime, String korisnickoIme, String lozinka, LocalDate datumRodjenja, String email, OvlastGosta ovlastGosta, String jmbag) {
        super(id, ime, prezime, korisnickoIme, lozinka, datumRodjenja, email);
        this.ovlastGosta = ovlastGosta;
        this.jmbag = jmbag;
    }

    public OvlastGosta getOvlastGosta() {
        return ovlastGosta;
    }

    public String getJmbag() {
        return jmbag;
    }
}