package entiteti;

import java.time.LocalDate;

public abstract class Korisnik {
    private final Integer id;
    private final String ime;
    private final String prezime;
    private final String korisnickoIme;
    private final String lozinka;
    private final LocalDate datumRodjenja;
    private final String email;

    public Korisnik(Integer id, String ime, String prezime, String korisnickoIme, String lozinka, LocalDate datumRodjenja, String email) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.korisnickoIme = korisnickoIme;
        this.lozinka = lozinka;
        this.datumRodjenja = datumRodjenja;
        this.email = email;
    }

    public Integer getId() {
        return id;
    }

    public String getIme() {
        return ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public String getLozinka() {
        return lozinka;
    }

    public LocalDate getDatumRodjenja() {
        return datumRodjenja;
    }

    public String getEmail() {
        return email;
    }
}