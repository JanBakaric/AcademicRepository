package dodatno;

public enum OvlastDjelatnika {
    ADMINISTRATOR(true, true), MODERATOR(true, false);

    private boolean ovlastOvjereKnjiga;
    private boolean ovlastOvjereKorisnika;

    OvlastDjelatnika(boolean ovlastOvjereKnjiga, boolean ovlastOvjereKorisnika) {
        this.ovlastOvjereKnjiga = ovlastOvjereKnjiga;
        this.ovlastOvjereKorisnika = ovlastOvjereKorisnika;
    }
}