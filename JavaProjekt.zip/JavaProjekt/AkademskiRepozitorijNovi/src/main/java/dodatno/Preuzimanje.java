package dodatno;

import iznimke.PreuzimanjeException;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;

public class Preuzimanje {
    private static String novaPutanja;

    public static void preuzmi(Stage stage, String putanja) throws PreuzimanjeException {
        FileChooser fileChooser = new FileChooser();
        String userHome = System.getProperty("user.home");
        File downloads = new File(userHome + "/Downloads");
        fileChooser.setInitialDirectory(downloads);

        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MSWord Files", "*.docx"));

        File selectedFile = fileChooser.showSaveDialog(stage);
        if (selectedFile != null) {
            try {
                Path putanjaDatoteke = Path.of(putanja);
                Path odabranaPutanja = selectedFile.toPath();

                if (Files.isSameFile(putanjaDatoteke, odabranaPutanja)) {
                    System.err.println("Ne možete kopirati datoteku na istu lokaciju.");
                } else if (selectedFile.getName().endsWith(".txt")) {
                    String ispis = Files.readString(putanjaDatoteke);
                    Files.write(odabranaPutanja, ispis.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                } else {
                    Files.copy(putanjaDatoteke, odabranaPutanja, StandardCopyOption.REPLACE_EXISTING);
                }
                novaPutanja = selectedFile.getAbsolutePath();
            } catch (IOException ioException) {
                throw new PreuzimanjeException(ioException.getMessage(), ioException.getCause());
            }
        }
    }

    public static void preuzmiIOtvori(Stage stage, String putanja) throws PreuzimanjeException {
        preuzmi(stage, putanja);
        if (novaPutanja != null) {
            File datoteka = new File(novaPutanja);
            try {
                Desktop desktop = Desktop.getDesktop();
                desktop.open(datoteka);
            } catch (IOException e) {
                System.err.println(e.getMessage() + "\n" + e.getCause());
            }
        }
    }
}
