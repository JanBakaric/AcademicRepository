package dodatno;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import static glavna.AkademskiRepozitorij.logger;

public class PasswordHasher {
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(password.getBytes());

            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            logger.warn(noSuchAlgorithmException.getMessage(), noSuchAlgorithmException.getCause());
        }
        return password;
    }
}
