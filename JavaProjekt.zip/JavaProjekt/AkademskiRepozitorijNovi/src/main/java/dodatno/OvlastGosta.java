package dodatno;

public enum OvlastGosta {
    OSNOVNOSKOLAC(true, false, false), SREDNJOSKOLAC(true, true, false), AKADEMIK(true, true, true);

    private boolean ovlastCitanjaLektira;
    private boolean ovlastCitanjaUdzbenika;
    private boolean ovlastCitanjaZnanstvenihRadova;

    OvlastGosta(boolean ovlastCitanjaLektira, boolean ovlastCitanjaUdzbenika, boolean ovlastCitanjaZnanstvenihRadova) {
        this.ovlastCitanjaLektira = ovlastCitanjaLektira;
        this.ovlastCitanjaUdzbenika = ovlastCitanjaUdzbenika;
        this.ovlastCitanjaZnanstvenihRadova = ovlastCitanjaZnanstvenihRadova;
    }
}
